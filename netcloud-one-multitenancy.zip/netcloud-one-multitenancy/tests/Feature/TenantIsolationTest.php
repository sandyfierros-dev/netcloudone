<?php

namespace Tests\Feature;

use App\Exceptions\TenantNotSetException;
use App\Models\Comment;
use App\Models\Empresa;
use App\Models\Event;
use App\Models\Membresia;
use App\Models\Post;
use App\Models\User;
use App\Support\TenantManager;
use Illuminate\Foundation\Testing\RefreshDatabase;
use LogicException;
use Tests\TestCase;

class TenantIsolationTest extends TestCase
{
    use RefreshDatabase;

    private TenantManager $tenant;
    private Empresa $a;
    private Empresa $b;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = app(TenantManager::class);
        $this->a = Empresa::create(['identificador' => 'empresa-a', 'nombre' => 'Empresa A']);
        $this->b = Empresa::create(['identificador' => 'empresa-b', 'nombre' => 'Empresa B']);
    }

    /** Crea un usuario con membresía, una publicación y un comentario dentro de la empresa dada. */
    private function seedTenant(Empresa $empresa, string $correo): array
    {
        $user = User::firstOrCreate(
            ['correo' => $correo],
            ['nombre' => 'Persona', 'contrasena' => 'secreto123']
        );

        return $this->tenant->runAs($empresa->id, function () use ($user) {
            $m = Membresia::create(['usuario_id' => $user->id, 'rol' => 'admin', 'estado' => 'activo']);
            $post = Post::create(['autor_membresia_id' => $m->id, 'contenido' => 'Hola']);
            $comment = Comment::create(['publicacion_id' => $post->id, 'autor_membresia_id' => $m->id, 'contenido' => 'Ok']);
            $event = Event::create([
                'creado_por_membresia_id' => $m->id, 'titulo' => 'Taller',
                'inicia_en' => now()->addDay(), 'termina_en' => now()->addDays(2),
            ]);
            return compact('m', 'post', 'comment', 'event');
        });
    }

    public function test_cada_empresa_solo_ve_sus_registros(): void
    {
        $da = $this->seedTenant($this->a, 'a@test.com');
        $this->seedTenant($this->b, 'b@test.com');

        $this->tenant->set($this->a->id);

        $this->assertSame(1, Post::count());
        $this->assertSame(1, Comment::count());
        $this->assertSame(1, Event::count());
        $this->assertSame(1, Membresia::count());
        $this->assertTrue(Post::first()->is($da['post']));
    }

    public function test_no_se_puede_leer_un_registro_de_otra_empresa_por_id(): void
    {
        $db = $this->seedTenant($this->b, 'b@test.com');

        $this->tenant->set($this->a->id);

        $this->assertNull(Post::find($db['post']->id));
    }

    public function test_empresa_id_se_asigna_automaticamente_al_crear(): void
    {
        $d = $this->seedTenant($this->a, 'a@test.com');

        $this->assertSame($this->a->id, $d['post']->empresa_id);
        $this->assertSame($this->a->id, $d['event']->empresa_id);
    }

    public function test_crear_sin_tenant_activo_lanza_excepcion(): void
    {
        $this->expectException(TenantNotSetException::class);

        $this->tenant->clear();
        Post::create(['autor_membresia_id' => 1, 'contenido' => 'x']);
    }

    public function test_sin_tenant_activo_las_consultas_no_devuelven_nada(): void
    {
        $this->seedTenant($this->a, 'a@test.com');
        $this->tenant->clear();

        $this->assertSame(0, Post::count());
    }

    public function test_no_se_puede_mover_un_registro_a_otra_empresa(): void
    {
        $d = $this->seedTenant($this->a, 'a@test.com');
        $this->tenant->set($this->a->id);

        $this->expectException(LogicException::class);
        $post = Post::find($d['post']->id);
        $post->empresa_id = $this->b->id;
        $post->save();
    }

    public function test_withoutTenant_salta_el_aislamiento(): void
    {
        $this->seedTenant($this->a, 'a@test.com');
        $this->seedTenant($this->b, 'b@test.com');
        $this->tenant->set($this->a->id);

        $this->assertSame(2, Post::withoutTenant()->count());
    }

    public function test_una_misma_persona_tiene_membresia_en_varias_empresas(): void
    {
        $this->seedTenant($this->a, 'multi@test.com');
        $this->seedTenant($this->b, 'multi@test.com');

        $user = User::where('correo', 'multi@test.com')->first();

        $this->assertSame(2, $user->membresias()->withoutTenant()->count());
    }
}
