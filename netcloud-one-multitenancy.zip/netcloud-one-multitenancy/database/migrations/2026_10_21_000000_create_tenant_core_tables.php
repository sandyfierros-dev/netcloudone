<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Subconjunto del ER v4 necesario para los modelos de esta entrega. Omítela si ya tienes tus migraciones. */
return new class extends Migration {
    public function up(): void
    {
        Schema::create('empresas', function (Blueprint $t) {
            $t->id();
            $t->string('identificador', 100)->unique();
            $t->string('nombre', 150);
            $t->enum('estado', ['activa', 'suspendida'])->default('activa');
            $t->timestamp('creado_en')->nullable();
            $t->timestamp('actualizado_en')->nullable();
            $t->timestamp('eliminado_en')->nullable();
        });

        Schema::create('usuarios', function (Blueprint $t) {
            $t->id();
            $t->string('nombre', 150);
            $t->string('correo', 255)->unique();
            $t->string('contrasena', 255);
            $t->string('telefono', 20)->nullable();
            $t->date('fecha_nacimiento')->nullable();
            $t->boolean('es_admin_plataforma')->default(false);
            $t->enum('estado', ['activo', 'inactivo'])->default('activo');
            $t->timestamp('creado_en')->nullable();
            $t->timestamp('actualizado_en')->nullable();
            $t->timestamp('eliminado_en')->nullable();
        });

        Schema::create('membresias', function (Blueprint $t) {
            $t->id();
            $t->foreignId('usuario_id')->constrained('usuarios');
            $t->foreignId('empresa_id')->constrained('empresas');
            $t->enum('rol', ['admin', 'miembro'])->default('miembro');
            $t->enum('estado', ['pendiente', 'activo', 'desactivado'])->default('activo');
            $t->date('fecha_socio')->nullable();
            $t->string('cargo', 100)->nullable();
            $t->string('foto_url', 255)->nullable();
            $t->text('biografia')->nullable();
            $t->boolean('perfil_visible')->default(true);
            $t->timestamp('creado_en')->nullable();
            $t->timestamp('actualizado_en')->nullable();
            $t->timestamp('eliminado_en')->nullable();
            $t->unique(['usuario_id', 'empresa_id']);
        });

        Schema::create('publicaciones', function (Blueprint $t) {
            $t->id();
            $t->foreignId('empresa_id')->constrained('empresas');
            $t->foreignId('autor_membresia_id')->constrained('membresias');
            $t->enum('tipo', ['publicacion', 'comunicado'])->default('publicacion');
            $t->text('contenido');
            $t->enum('visibilidad', ['empresa', 'audiencia'])->default('empresa');
            $t->enum('estado', ['publicada', 'oculta'])->default('publicada');
            $t->timestamp('editado_en')->nullable();
            $t->timestamp('creado_en')->nullable();
            $t->timestamp('actualizado_en')->nullable();
            $t->timestamp('eliminado_en')->nullable();
        });

        Schema::create('comentarios', function (Blueprint $t) {
            $t->id();
            $t->foreignId('empresa_id')->constrained('empresas');
            $t->foreignId('publicacion_id')->constrained('publicaciones');
            $t->foreignId('autor_membresia_id')->constrained('membresias');
            $t->text('contenido');
            $t->enum('estado', ['visible', 'oculto'])->default('visible');
            $t->timestamp('editado_en')->nullable();
            $t->timestamp('creado_en')->nullable();
            $t->timestamp('actualizado_en')->nullable();
            $t->timestamp('eliminado_en')->nullable();
        });

        Schema::create('eventos', function (Blueprint $t) {
            $t->id();
            $t->foreignId('empresa_id')->constrained('empresas');
            $t->foreignId('creado_por_membresia_id')->constrained('membresias');
            $t->string('titulo', 200);
            $t->text('descripcion')->nullable();
            $t->dateTime('inicia_en');
            $t->dateTime('termina_en');
            $t->string('lugar', 255)->nullable();
            $t->unsignedInteger('cupo')->nullable();
            $t->enum('tipo', ['presencial', 'virtual', 'hibrido'])->default('presencial');
            $t->enum('estado', ['programado', 'cancelado', 'finalizado'])->default('programado');
            $t->timestamp('creado_en')->nullable();
            $t->timestamp('actualizado_en')->nullable();
            $t->timestamp('eliminado_en')->nullable();
        });
    }

    public function down(): void
    {
        foreach (['eventos', 'comentarios', 'publicaciones', 'membresias', 'usuarios', 'empresas'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
