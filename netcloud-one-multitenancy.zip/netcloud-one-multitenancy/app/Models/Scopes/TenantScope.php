<?php

namespace App\Models\Scopes;

use App\Support\TenantManager;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;

/**
 * Global Scope: filtra toda consulta por empresa_id.
 * Falla cerrado: sin tenant activo no devuelve nada (evita fugas entre empresas).
 */
class TenantScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        $tenantId = app(TenantManager::class)->id();

        if ($tenantId === null) {
            $builder->whereRaw('1 = 0');
            return;
        }

        $builder->where($model->getTable() . '.empresa_id', $tenantId);
    }
}
