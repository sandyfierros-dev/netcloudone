<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

/**
 * Cuenta global (ONE ID). La tabla usuarios NO tiene empresa_id: una persona
 * puede pertenecer a varias empresas. Por eso User no usa BelongsToTenant;
 * el aislamiento se aplica en Membresia y en el resto de modelos.
 */
class User extends Authenticatable
{
    use HasApiTokens, SoftDeletes;

    protected $table = 'usuarios';
    const CREATED_AT = 'creado_en';
    const UPDATED_AT = 'actualizado_en';
    const DELETED_AT = 'eliminado_en';

    protected $fillable = ['nombre', 'correo', 'contrasena', 'telefono', 'fecha_nacimiento'];
    protected $hidden = ['contrasena'];

    protected function casts(): array
    {
        return [
            'contrasena' => 'hashed',
            'es_admin_plataforma' => 'boolean',
            'fecha_nacimiento' => 'date',
        ];
    }

    public function getAuthPassword(): string
    {
        return $this->contrasena;
    }

    public function membresias(): HasMany
    {
        return $this->hasMany(Membresia::class, 'usuario_id');
    }
}
