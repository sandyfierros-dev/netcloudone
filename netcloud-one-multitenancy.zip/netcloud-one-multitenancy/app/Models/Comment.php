<?php

namespace App\Models;

use App\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Comment extends Model
{
    use BelongsToTenant, SoftDeletes;

    protected $table = 'comentarios';
    const CREATED_AT = 'creado_en';
    const UPDATED_AT = 'actualizado_en';
    const DELETED_AT = 'eliminado_en';

    protected $fillable = ['publicacion_id', 'autor_membresia_id', 'contenido', 'estado'];

    public function post(): BelongsTo
    {
        return $this->belongsTo(Post::class, 'publicacion_id');
    }

    public function autor(): BelongsTo
    {
        return $this->belongsTo(Membresia::class, 'autor_membresia_id');
    }
}
