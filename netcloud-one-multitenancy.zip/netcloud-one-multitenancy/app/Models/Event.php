<?php

namespace App\Models;

use App\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/** ONE Events. */
class Event extends Model
{
    use BelongsToTenant, SoftDeletes;

    protected $table = 'eventos';
    const CREATED_AT = 'creado_en';
    const UPDATED_AT = 'actualizado_en';
    const DELETED_AT = 'eliminado_en';

    protected $fillable = [
        'creado_por_membresia_id', 'titulo', 'descripcion',
        'inicia_en', 'termina_en', 'lugar', 'cupo', 'tipo', 'estado',
    ];

    protected function casts(): array
    {
        return ['inicia_en' => 'datetime', 'termina_en' => 'datetime'];
    }

    public function creador(): BelongsTo
    {
        return $this->belongsTo(Membresia::class, 'creado_por_membresia_id');
    }
}
