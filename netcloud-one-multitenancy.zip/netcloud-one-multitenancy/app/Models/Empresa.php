<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/** La empresa es el tenant: NO usa BelongsToTenant. */
class Empresa extends Model
{
    use SoftDeletes;

    protected $table = 'empresas';
    const CREATED_AT = 'creado_en';
    const UPDATED_AT = 'actualizado_en';
    const DELETED_AT = 'eliminado_en';

    protected $fillable = ['identificador', 'nombre', 'estado'];

    public function estaActiva(): bool
    {
        return $this->estado === 'activa';
    }
}
