<?php

namespace App\Models;

use App\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/** ONE Feed: publicación o comunicado. */
class Post extends Model
{
    use BelongsToTenant, SoftDeletes;

    protected $table = 'publicaciones';
    const CREATED_AT = 'creado_en';
    const UPDATED_AT = 'actualizado_en';
    const DELETED_AT = 'eliminado_en';

    protected $fillable = ['autor_membresia_id', 'tipo', 'contenido', 'visibilidad', 'estado'];

    public function autor(): BelongsTo
    {
        return $this->belongsTo(Membresia::class, 'autor_membresia_id');
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class, 'publicacion_id');
    }
}
