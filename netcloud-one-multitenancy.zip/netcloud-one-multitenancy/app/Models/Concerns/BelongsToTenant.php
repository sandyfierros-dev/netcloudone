<?php

namespace App\Models\Concerns;

use App\Exceptions\TenantNotSetException;
use App\Models\Empresa;
use App\Models\Scopes\TenantScope;
use App\Support\TenantManager;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use LogicException;

/**
 * Trait de aislamiento multi-tenant.
 * Aplícalo a todo modelo cuya tabla tenga la columna empresa_id.
 */
trait BelongsToTenant
{
    public static function bootBelongsToTenant(): void
    {
        // 1. Lecturas, updates y deletes quedan filtrados por empresa_id.
        static::addGlobalScope(new TenantScope());

        // 2. Al crear, empresa_id se toma SIEMPRE del tenant activo (no del request).
        static::creating(function ($model) {
            $tenantId = app(TenantManager::class)->id();

            if ($tenantId === null) {
                throw new TenantNotSetException();
            }

            $model->empresa_id = $tenantId;
        });

        // 3. Un registro nunca se puede mover a otra empresa.
        static::updating(function ($model) {
            if ($model->isDirty('empresa_id')) {
                throw new LogicException('No se puede cambiar la empresa de un registro.');
            }
        });
    }

    public function empresa(): BelongsTo
    {
        return $this->belongsTo(Empresa::class, 'empresa_id');
    }

    /** Salta el aislamiento de forma explícita (uso excepcional: middleware, admin global). */
    public function scopeWithoutTenant(Builder $query): Builder
    {
        return $query->withoutGlobalScope(TenantScope::class);
    }
}
