<?php

namespace App\Models;

use App\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/** Vínculo usuario <-> empresa. Casi todo lo que se hace en una empresa lo hace una membresía. */
class Membresia extends Model
{
    use BelongsToTenant, SoftDeletes;

    protected $table = 'membresias';
    const CREATED_AT = 'creado_en';
    const UPDATED_AT = 'actualizado_en';
    const DELETED_AT = 'eliminado_en';

    protected $fillable = [
        'usuario_id', 'rol', 'estado', 'fecha_socio',
        'cargo', 'foto_url', 'biografia', 'perfil_visible',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'usuario_id');
    }

    public function esAdmin(): bool
    {
        return $this->rol === 'admin';
    }
}
