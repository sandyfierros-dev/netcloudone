<?php

namespace App\Exceptions;

use RuntimeException;

class TenantNotSetException extends RuntimeException
{
    public function __construct(string $message = 'No hay una empresa (tenant) activa en este contexto.')
    {
        parent::__construct($message);
    }
}
