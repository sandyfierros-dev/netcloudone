<?php

namespace App\Support;

use Closure;

/**
 * Guarda la empresa (tenant) activa durante la petición.
 * Se registra como singleton en AppServiceProvider.
 */
class TenantManager
{
    protected ?int $tenantId = null;

    public function set(int $tenantId): void
    {
        $this->tenantId = $tenantId;
    }

    public function id(): ?int
    {
        return $this->tenantId;
    }

    public function check(): bool
    {
        return $this->tenantId !== null;
    }

    public function clear(): void
    {
        $this->tenantId = null;
    }

    /** Ejecuta un bloque como otra empresa y restaura la anterior (seeders, jobs, pruebas). */
    public function runAs(int $tenantId, Closure $callback): mixed
    {
        $previous = $this->tenantId;
        $this->tenantId = $tenantId;

        try {
            return $callback();
        } finally {
            $this->tenantId = $previous;
        }
    }
}
