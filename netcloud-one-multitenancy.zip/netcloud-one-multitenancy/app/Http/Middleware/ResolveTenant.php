<?php

namespace App\Http\Middleware;

use App\Models\Empresa;
use App\Models\Membresia;
use App\Support\TenantManager;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Define el tenant activo a partir de la empresa elegida en el selector (ONE ID)
 * y valida que el usuario tenga una membresía vigente en ella.
 * Registrar DESPUÉS de la autenticación.
 */
class ResolveTenant
{
    public function __construct(private TenantManager $tenant) {}

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        $empresaId = (int) ($request->session()->get('empresa_activa_id') ?? $request->header('X-Empresa-Id'));

        abort_unless($user && $empresaId, 403, 'Selecciona una empresa.');

        $empresa = Empresa::find($empresaId);
        abort_unless($empresa && $empresa->estaActiva(), 403, 'Empresa no disponible.');

        $membresia = Membresia::withoutTenant()
            ->where('usuario_id', $user->id)
            ->where('empresa_id', $empresaId)
            ->where('estado', 'activo')
            ->first();
        abort_unless($membresia, 403, 'No tienes una membresía activa en esta empresa.');

        $this->tenant->set($empresaId);
        $request->attributes->set('membresia', $membresia);

        try {
            return $next($request);
        } finally {
            $this->tenant->clear();
        }
    }
}
