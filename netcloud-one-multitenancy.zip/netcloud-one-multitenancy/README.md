# Netcloud One — Multi-tenancy (Trait BelongsToTenant + Global Scope)

## Dónde copiar cada archivo (proyecto Laravel 11+)
| Archivo | Destino |
|---|---|
| app/Support/TenantManager.php | igual |
| app/Exceptions/TenantNotSetException.php | igual |
| app/Models/Scopes/TenantScope.php | igual |
| app/Models/Concerns/BelongsToTenant.php | igual |
| app/Models/{Empresa,User,Membresia,Post,Comment,Event}.php | igual (reemplaza User.php) |
| app/Http/Middleware/ResolveTenant.php | igual |
| database/migrations/..._create_tenant_core_tables.php | opcional si ya tienes tus migraciones |
| tests/Feature/TenantIsolationTest.php | igual |

## Registro (2 cambios)

`app/Providers/AppServiceProvider.php`
```php
use App\Support\TenantManager;

public function register(): void
{
    $this->app->singleton(TenantManager::class);
}
```

`bootstrap/app.php`
```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->alias(['tenant' => \App\Http\Middleware\ResolveTenant::class]);
})
```

Uso en rutas (después de autenticar): `Route::middleware(['auth:sanctum', 'tenant'])->group(...)`

## Probar
```bash
php artisan migrate
php artisan test --filter=TenantIsolationTest
```
(Para las pruebas configura sqlite en memoria en phpunit.xml o usa una BD MySQL de pruebas.)

## Commit
```bash
git add app database tests
git commit -m "feat: multi-tenancy trait and models (User, Post, Comment, Event)"
```
