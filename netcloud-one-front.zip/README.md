# Netcloud One — Front (Blade + CSS + JS)

Maquetado completo de las vistas de los 3 actores, sin dependencias externas (no usa CDN, Bootstrap ni Vite).

## Instalación (Laravel 11+)
1. Copia estas carpetas dentro de tu proyecto, respetando rutas:
   - `resources/views/**`  → vistas, layouts y componentes Blade
   - `public/css/netcloud.css` y `public/js/netcloud.js`
   - `app/Support/Demo.php` → datos de ejemplo (solo para maquetar)
2. Reemplaza `routes/web.php` por el incluido (o fusiona las rutas).
3. `php artisan serve` y abre `http://localhost:8000/login`.

## Cómo funciona el white-label
Cada layout de empresa (`layouts/company`, `layouts/admin`) inyecta `--brand` en `:root`
con el color de la empresa; todo el CSS se pinta con esa variable. Al conectar el backend,
pasa `$tenant` (nombre, iniciales/logo, color) desde un View Composer o middleware.

## Mapa de pantallas
| Actor | Ruta | Vista |
|---|---|---|
| ONE ID | /login, /registro | auth/access |
| | /recuperar-contrasena(/enviado) | auth/forgot |
| | /restablecer-contrasena/{token} | auth/reset |
| | /invitacion/{token} | auth/invitation |
| | /empresas | auth/select-company |
| | /admin/login, /admin-global/login | auth/login-admin |
| Usuario | /app | app/feed/index |
| | /app/directorio, /app/directorio/{id} | app/directory/index, show |
| | /app/eventos, /app/eventos/{id} | app/events/index, show |
| | /app/chat | app/chat/index |
| | /app/perfil | app/profile/edit |
| | /app/notificaciones | app/notifications/index |
| Admin global | /admin-global | global/dashboard |
| | /admin-global/empresas (+ nueva, {id}, {id}/editar) | global/companies/* |
| | /admin-global/integraciones | global/integrations/index |
| Admin empresa | /admin | admin/dashboard |
| | /admin/miembros | admin/members/index |
| | /admin/directorio | admin/directory/index |
| | /admin/feed | admin/feed/index |
| | /admin/eventos (+ nuevo, editar, asistentes) | admin/events/* |
| | /admin/chat | admin/chat/index |
| | /admin/personalizacion | admin/branding/index |
| | /admin/notificaciones | admin/notifications/index |

## Pendiente al conectar el backend
- Los formularios usan `action="#"`: apunta cada uno a su ruta POST/PUT.
- Sustituye `Demo::*` por consultas Eloquent con el scope de `tenant_id`.
- Los botones "Iniciar sesión" son enlaces de navegación para poder recorrer el prototipo.
