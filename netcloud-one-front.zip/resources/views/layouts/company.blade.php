@php
  $tenant = $tenant ?? \App\Support\Demo::tenant();
  $me = \App\Support\Demo::user();
  $notifs = \App\Support\Demo::notifications();
  $unread = collect($notifs)->where('unread', true)->count();
@endphp
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title') · {{ $tenant['name'] }}</title>
  <link rel="stylesheet" href="{{ asset('css/netcloud.css') }}">
  {{-- White-label: el color de la empresa se inyecta como variable CSS --}}
  <style>:root{--brand: {{ $tenant['color'] }};}</style>
</head>
<body>
<header class="topbar">
  <div class="topbar-in">
    <a class="brandline" href="{{ route('app.feed') }}"><span class="tenant-logo">{{ $tenant['initials'] }}</span><span>{{ $tenant['name'] }}</span></a>
    <nav class="topnav">
      <a href="{{ route('app.feed') }}" class="{{ request()->routeIs('app.feed') ? 'on' : '' }}"><x-icon name="home" /> Inicio</a>
      <a href="{{ route('app.directory') }}" class="{{ request()->routeIs('app.directory*') ? 'on' : '' }}"><x-icon name="users" /> Directorio</a>
      <a href="{{ route('app.events') }}" class="{{ request()->routeIs('app.events*') ? 'on' : '' }}"><x-icon name="calendar" /> Eventos</a>
      <a href="{{ route('app.chat') }}" class="{{ request()->routeIs('app.chat') ? 'on' : '' }}"><x-icon name="message" /> Chat</a>
    </nav>
    <span class="grow" style="flex:1"></span>
    <div class="menu">
      <button class="icon-btn" data-menu aria-label="Notificaciones"><x-icon name="bell" />@if($unread)<span class="pip"></span>@endif</button>
      <div class="menu-list notif-pop">
        <div style="padding:.4rem .6rem"><b>Notificaciones</b></div>
        @foreach(array_slice($notifs, 0, 4) as $n)
          <div class="notif-item {{ $n['unread'] ? 'unread' : '' }}"><x-icon name="{{ $n['icon'] }}" /><div><div class="small">{{ $n['text'] }}</div><small class="muted">{{ $n['time'] }}</small></div></div>
        @endforeach
        <hr><a href="{{ route('app.notifications') }}">Ver todas</a>
      </div>
    </div>
    <div class="menu">
      <button class="icon-btn" data-menu style="padding:0;background:none" aria-label="Mi cuenta"><x-avatar :name="$me['name']" /></button>
      <div class="menu-list">
        <div style="padding:.4rem .7rem"><b>{{ $me['name'] }}</b><br><small class="muted">{{ $me['email'] }}</small></div><hr>
        <a href="{{ route('app.profile') }}"><x-icon name="user" /> Mi perfil</a>
        <a href="{{ route('company.select') }}"><x-icon name="building" /> Cambiar de empresa</a>
        <form method="post" action="{{ route('logout') }}">@csrf<button><x-icon name="log-out" /> Cerrar sesión</button></form>
      </div>
    </div>
  </div>
</header>

<main class="container">
  @yield('content')
</main>

<nav class="bottom-nav">
  <a href="{{ route('app.feed') }}" class="{{ request()->routeIs('app.feed') ? 'on' : '' }}"><x-icon name="home" />Inicio</a>
  <a href="{{ route('app.directory') }}" class="{{ request()->routeIs('app.directory*') ? 'on' : '' }}"><x-icon name="users" />Directorio</a>
  <a href="{{ route('app.events') }}" class="{{ request()->routeIs('app.events*') ? 'on' : '' }}"><x-icon name="calendar" />Eventos</a>
  <a href="{{ route('app.chat') }}" class="{{ request()->routeIs('app.chat') ? 'on' : '' }}"><x-icon name="message" />Chat</a>
  <a href="{{ route('app.profile') }}" class="{{ request()->routeIs('app.profile') || request()->routeIs('app.notifications') ? 'on' : '' }}"><x-icon name="user" />Perfil</a>
</nav>
<script src="{{ asset('js/netcloud.js') }}"></script>
@stack('scripts')
</body>
</html>
