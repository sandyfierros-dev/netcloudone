<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title', 'Acceso') · Netcloud One</title>
  <link rel="stylesheet" href="{{ asset('css/netcloud.css') }}">
  @stack('head')
</head>
<body class="theme-global auth-body">
  <main class="auth-wrap">
    <div class="auth-brand"><x-logo /></div>
    @yield('content')
    <p class="auth-foot">© {{ date('Y') }} Netcloud Services. Todos los derechos reservados.</p>
  </main>
  <script src="{{ asset('js/netcloud.js') }}"></script>
</body>
</html>
