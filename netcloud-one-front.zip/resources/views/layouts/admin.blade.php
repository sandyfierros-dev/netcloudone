@php
  $tenant = $tenant ?? \App\Support\Demo::tenant();
  $adminName = 'Marcela Ríos';
@endphp
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title') · Administración · {{ $tenant['name'] }}</title>
  <link rel="stylesheet" href="{{ asset('css/netcloud.css') }}">
  <style>:root{--brand: {{ $tenant['color'] }};}</style>
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="side-top"><div class="cell"><span class="tenant-logo">{{ $tenant['initials'] }}</span><div style="line-height:1.2"><b>{{ $tenant['name'] }}</b><br><small class="muted">Panel de administración</small></div></div></div>
    <nav>
      <a class="nav-link {{ request()->routeIs('admin.dashboard') ? 'on' : '' }}" href="{{ route('admin.dashboard') }}"><x-icon name="home" /> Inicio</a>
      <a class="nav-link {{ request()->routeIs('admin.members') ? 'on' : '' }}" href="{{ route('admin.members') }}"><x-icon name="users" /> Miembros</a>
      <div class="side-title">Módulos</div>
      <a class="nav-link {{ request()->routeIs('admin.directory') ? 'on' : '' }}" href="{{ route('admin.directory') }}"><x-icon name="user" /> Directorio</a>
      <a class="nav-link {{ request()->routeIs('admin.feed') ? 'on' : '' }}" href="{{ route('admin.feed') }}"><x-icon name="layout" /> Feed</a>
      <a class="nav-link {{ request()->routeIs('admin.events*') ? 'on' : '' }}" href="{{ route('admin.events') }}"><x-icon name="calendar" /> Eventos</a>
      <a class="nav-link {{ request()->routeIs('admin.chat') ? 'on' : '' }}" href="{{ route('admin.chat') }}"><x-icon name="message" /> Chat</a>
      <div class="side-title">Configuración</div>
      <a class="nav-link {{ request()->routeIs('admin.branding') ? 'on' : '' }}" href="{{ route('admin.branding') }}"><x-icon name="droplet" /> Personalización</a>
      <a class="nav-link {{ request()->routeIs('admin.notifications') ? 'on' : '' }}" href="{{ route('admin.notifications') }}"><x-icon name="bell" /> Notificaciones</a>
    </nav>
    <div class="side-bottom">
      <a class="btn btn-outline btn-block btn-sm" href="{{ route('app.feed') }}"><x-icon name="eye" /> Ver como miembro</a>
      <form method="post" action="{{ route('logout') }}" class="mt">@csrf<button class="btn btn-ghost btn-block btn-sm"><x-icon name="log-out" /> Cerrar sesión</button></form>
    </div>
  </aside>
  <div class="scrim"></div>
  <div class="main">
    <header class="top">
      <button class="icon-btn burger" data-burger aria-label="Menú"><x-icon name="menu" /></button>
      <h1 class="grow">@yield('title')</h1>
      <div class="user-chip"><x-avatar :name="$adminName" size="sm" /><div class="meta"><b>{{ $adminName }}</b><br><small>Administradora</small></div></div>
    </header>
    <div class="content">
      @yield('content')
    </div>
  </div>
</div>
<script src="{{ asset('js/netcloud.js') }}"></script>
@stack('scripts')
</body>
</html>
