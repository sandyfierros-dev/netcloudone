<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title') · Admin global · Netcloud One</title>
  <link rel="stylesheet" href="{{ asset('css/netcloud.css') }}">
</head>
<body class="theme-global">
<div class="shell">
  <aside class="sidebar">
    <div class="side-top"><x-logo /></div>
    <nav>
      <div class="side-title">Plataforma</div>
      <a class="nav-link {{ request()->routeIs('global.dashboard') ? 'on' : '' }}" href="{{ route('global.dashboard') }}"><x-icon name="grid" /> Panel</a>
      <a class="nav-link {{ request()->routeIs('global.companies*') ? 'on' : '' }}" href="{{ route('global.companies') }}"><x-icon name="building" /> Empresas</a>
      <a class="nav-link {{ request()->routeIs('global.integrations') ? 'on' : '' }}" href="{{ route('global.integrations') }}"><x-icon name="zap" /> Integraciones</a>
    </nav>
    <div class="side-bottom">
      <div class="user-chip"><x-avatar name="Admin Netcloud" /><div class="meta"><b>Admin Netcloud</b><br><small>Administrador global</small></div></div>
      <form method="post" action="{{ route('logout') }}" class="mt">@csrf<button class="btn btn-outline btn-block btn-sm"><x-icon name="log-out" /> Cerrar sesión</button></form>
    </div>
  </aside>
  <div class="scrim"></div>
  <div class="main">
    <header class="top">
      <button class="icon-btn burger" data-burger aria-label="Menú"><x-icon name="menu" /></button>
      <h1 class="grow">@yield('title')</h1>
      <div class="user-chip"><x-avatar name="Admin Netcloud" size="sm" /><div class="meta"><b>Admin Netcloud</b></div></div>
    </header>
    <div class="content">
      @yield('content')
    </div>
  </div>
</div>
<script src="{{ asset('js/netcloud.js') }}"></script>
@stack('scripts')
</body>
</html>
