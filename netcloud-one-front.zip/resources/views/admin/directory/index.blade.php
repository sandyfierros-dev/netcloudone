@extends('layouts.admin')
@section('title', 'Directorio')
@section('content')
<div class="grid g2 mb" style="align-items:start">
  <div class="card">
    <div class="card-head"><h2>Campos visibles</h2></div>
    <div class="card-body">
      <p class="muted small">Define qué datos pueden ver los demás miembros en cada perfil.</p>
      @foreach(['Teléfono' => true, 'Correo electrónico' => true, 'Cargo' => true, 'Área' => true, 'Biografía' => false] as $campo => $on)
        <div class="setting-row"><p><b>{{ $campo }}</b></p><label class="switch"><input type="checkbox" {{ $on ? 'checked' : '' }}><span></span></label></div>
      @endforeach
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h2>Agrupación</h2></div>
    <div class="card-body">
      <p class="muted small">Cómo se agrupan los miembros en el directorio.</p>
      <label class="check mb"><input type="radio" name="group" checked> Por departamento / área</label>
      <label class="check mb"><input type="radio" name="group"> Por categoría</label>
      <label class="check"><input type="radio" name="group"> Sin agrupar</label>
      <div class="form-actions"><button class="btn">Guardar configuración</button></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>Perfiles</h2><div class="input-icon" style="width:260px;max-width:100%"><x-icon name="search" /><input type="search" placeholder="Buscar perfil…" data-filter=".prof-row"></div></div>
  <div class="table-wrap"><table>
    <thead><tr><th>Miembro</th><th>Cargo</th><th>Área</th><th>Visible</th><th></th></tr></thead>
    <tbody>
      @foreach($members as $m)
        <tr class="prof-row">
          <td><div class="cell"><x-avatar :name="$m['name']" size="sm" /><b>{{ $m['name'] }}</b></div></td>
          <td>{{ $m['title'] }}</td><td>{{ $m['area'] }}</td>
          <td><label class="switch"><input type="checkbox" {{ $m['status'] === 'Activo' ? 'checked' : '' }}><span></span></label></td>
          <td><div class="actions"><button class="btn btn-outline btn-sm"><x-icon name="edit" /> Editar</button></div></td>
        </tr>
      @endforeach
    </tbody>
  </table></div>
</div>
@endsection
