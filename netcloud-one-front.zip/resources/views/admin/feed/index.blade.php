@extends('layouts.admin')
@section('title', 'Feed')
@section('content')
<form class="card composer" method="post" action="#">@csrf
  <div class="composer-row"><x-avatar name="Marcela Ríos" /><textarea placeholder="Escribe un comunicado oficial para toda la comunidad…"></textarea></div>
  <div class="composer-tools">
    <label class="check small"><input type="checkbox"> <x-icon name="bookmark" /> Fijar publicación</label>
    <button class="btn btn-sm"><x-icon name="send" /> Publicar comunicado</button>
  </div>
</form>

<div class="tabs" data-tabs><button class="tab on" data-tab="posts">Publicaciones</button><button class="tab" data-tab="reported">Reportadas <span class="badge bad">2</span></button></div>
<div>
  <div class="tab-panel on" data-panel="posts">
    @foreach($posts as $p)
      <article class="card post {{ $p['pinned'] ? 'pinned' : '' }}">
        <div class="post-head">
          <x-avatar :name="$p['author']" />
          <div class="who"><b>{{ $p['author'] }}</b> @if($p['pinned'])<span class="badge warn"><x-icon name="bookmark" /> Fijada</span>@endif<br><small class="muted">{{ $p['time'] }}</small></div>
          <div class="actions">
            <button class="btn btn-outline btn-sm"><x-icon name="bookmark" /> {{ $p['pinned'] ? 'Desfijar' : 'Fijar' }}</button>
            <button class="btn btn-outline btn-sm"><x-icon name="eye" /> Ocultar</button>
            <button class="btn btn-danger btn-sm" data-modal-open="modal-del" title="Eliminar"><x-icon name="trash" /></button>
          </div>
        </div>
        <div class="post-body">{{ $p['text'] }}</div>
        @if(count($p['comments']))
          <div class="thread open">
            @foreach($p['comments'] as $c)
              <div class="comment"><x-avatar :name="$c[0]" size="sm" /><div class="bubble" style="flex:1"><b>{{ $c[0] }}</b><br>{{ $c[1] }}</div>
                <button class="btn btn-ghost btn-sm" data-modal-open="modal-del" title="Eliminar comentario"><x-icon name="trash" /></button></div>
            @endforeach
          </div>
        @endif
      </article>
    @endforeach
  </div>
  <div class="tab-panel" data-panel="reported">
    <div class="card">
      @foreach([['Diego Cárdenas', 'Publicación con enlaces externos sospechosos.'], ['Iván Olvera', 'Comentario con lenguaje inapropiado.']] as $r)
        <div class="channel"><x-avatar :name="$r[0]" /><div style="flex:1"><b>{{ $r[0] }}</b><br><span class="muted small">{{ $r[1] }}</span></div>
          <button class="btn btn-outline btn-sm">Conservar</button><button class="btn btn-danger btn-sm">Eliminar</button></div>
      @endforeach
    </div>
  </div>
</div>

<div class="modal-bg" id="modal-del"><div class="modal">
  <h2>¿Eliminar contenido?</h2><p class="muted">Esta acción no se puede deshacer.</p>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Cancelar</button><button class="btn btn-danger" data-modal-close>Eliminar</button></div>
</div></div>
@endsection
