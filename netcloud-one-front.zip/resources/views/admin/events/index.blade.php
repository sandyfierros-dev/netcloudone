@extends('layouts.admin')
@section('title', 'Eventos')
@section('content')
<div class="page-head"><p class="muted">Crea y gestiona los eventos de tu comunidad.</p><a class="btn" href="{{ route('admin.events.create') }}"><x-icon name="plus" /> Crear evento</a></div>

<div class="grid split mb" style="align-items:start">
  {{-- Calendario (maqueta de noviembre 2026) --}}
  <div class="card card-body">
    <div class="page-head" style="margin-bottom:.6rem"><h2 style="margin:0">Noviembre 2026</h2><div><button class="btn btn-outline btn-sm">‹</button> <button class="btn btn-outline btn-sm">›</button></div></div>
    @php
      $evDays = [5 => 'Taller de liderazgo', 12 => 'Desayuno', 19 => 'Webinar 2027'];
    @endphp
    <div class="cal">
      @foreach(['L','M','M','J','V','S','D'] as $d)<div class="h">{{ $d }}</div>@endforeach
      @for($i = 1; $i <= 30; $i++)
        @if($i === 1)@for($k = 0; $k < 6; $k++)<div class="d off"></div>@endfor @endif
        <div class="d"><b>{{ $i }}</b>@isset($evDays[$i])<span class="ev">{{ $evDays[$i] }}</span>@endisset</div>
      @endfor
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>Todos los eventos</h3></div>
    @foreach($events as $e)
      <div class="channel">
        <div class="date-pill" style="width:50px;padding:.3rem 0"><b style="font-size:1.1rem">{{ $e['day'] }}</b><span>{{ $e['month'] }}</span></div>
        <div style="flex:1;min-width:0"><b>{{ $e['title'] }}</b><br><small class="muted">{{ $e['going'] }}/{{ $e['cap'] }} · <x-status :value="$e['status']" /></small></div>
        <div class="menu"><button class="icon-btn" data-menu aria-label="Acciones"><x-icon name="more" /></button>
          <div class="menu-list">
            <a href="{{ route('admin.events.attendees', $e['id']) }}"><x-icon name="users" /> Ver asistentes</a>
            <a href="{{ route('admin.events.edit', $e['id']) }}"><x-icon name="edit" /> Editar</a>
            <button data-modal-open="modal-remind"><x-icon name="bell" /> Enviar recordatorio</button>
            <hr><button data-modal-open="modal-cancel" style="color:var(--bad)"><x-icon name="x" /> Cancelar evento</button>
          </div></div>
      </div>
    @endforeach
  </div>
</div>

<div class="modal-bg" id="modal-cancel"><div class="modal">
  <h2>¿Cancelar evento?</h2><p class="muted">Se notificará a los asistentes confirmados.</p>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Volver</button><button class="btn btn-danger" data-modal-close>Cancelar evento</button></div>
</div></div>
<div class="modal-bg" id="modal-remind"><div class="modal">
  <h2>Enviar recordatorio</h2><p class="muted">Se enviará mediante n8n por los canales activos (correo / WhatsApp).</p>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Cancelar</button><button class="btn" data-modal-close><x-icon name="send" /> Enviar ahora</button></div>
</div></div>
@endsection
