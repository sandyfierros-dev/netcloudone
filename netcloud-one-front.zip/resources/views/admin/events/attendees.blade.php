@extends('layouts.admin')
@section('title', 'Asistentes')
@section('content')
<div class="page-head">
  <div><a href="{{ route('admin.events') }}" class="btn btn-ghost btn-sm"><x-icon name="arrow-left" /> Eventos</a></div>
  <button class="btn btn-outline"><x-icon name="upload" /> Exportar lista</button>
</div>
<div class="card mb card-body"><h2 style="margin:0">{{ $e['title'] }}</h2><span class="muted">{{ $e['date'] }} · {{ $e['place'] }}</span>
  <div class="mt"><b>{{ $e['going'] }}</b> de {{ $e['cap'] }} cupos confirmados</div></div>
<div class="card"><div class="table-wrap"><table>
  <thead><tr><th>Asistente</th><th>Área</th><th>Confirmó</th></tr></thead>
  <tbody>@foreach($members as $m)<tr><td><div class="cell"><x-avatar :name="$m['name']" size="sm" /><b>{{ $m['name'] }}</b></div></td><td>{{ $m['area'] }}</td><td class="muted">Hace {{ $loop->iteration }} d</td></tr>@endforeach</tbody>
</table></div></div>
@endsection
