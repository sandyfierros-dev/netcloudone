@extends('layouts.admin')
@section('title', $e ? 'Editar evento' : 'Crear evento')
@section('content')
<form method="post" action="#" class="narrow" style="margin:0;max-width:760px">@csrf
  <div class="card mb"><div class="card-body">
    <div class="field"><label for="ev-t">Título</label><input id="ev-t" name="title" value="{{ $e['title'] ?? '' }}" required></div>
    <div class="field"><label for="ev-d">Descripción</label><textarea id="ev-d" name="description">{{ $e['desc'] ?? '' }}</textarea></div>
    <div class="grid g2">
      <div class="field"><label for="ev-s">Inicio</label><input id="ev-s" type="datetime-local" name="starts_at"></div>
      <div class="field"><label for="ev-e">Fin</label><input id="ev-e" type="datetime-local" name="ends_at"></div>
    </div>
    <div class="field"><label for="ev-p">Lugar</label><input id="ev-p" name="place" value="{{ $e['place'] ?? '' }}"></div>
    <div class="grid g2">
      <div class="field"><label for="ev-c">Cupo</label><input id="ev-c" type="number" min="1" name="capacity" value="{{ $e['cap'] ?? '' }}"></div>
      <div class="field"><label for="ev-m">Tipo de evento</label><select id="ev-m" name="type"><option>Presencial</option><option>Virtual</option><option>Híbrido</option></select></div>
    </div>
    <label class="check"><input type="checkbox" checked> Notificar a los miembros al publicar</label>
  </div></div>
  <div class="form-actions"><a class="btn btn-outline" href="{{ route('admin.events') }}">Cancelar</a><button class="btn">{{ $e ? 'Guardar cambios' : 'Crear evento' }}</button></div>
</form>
@endsection
