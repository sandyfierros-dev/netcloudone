@extends('layouts.admin')
@section('title', 'Personalización')
@section('content')
<div class="grid g2" style="align-items:start">
  <form class="card" method="post" action="#" enctype="multipart/form-data">@csrf
    <div class="card-head"><h2>Identidad visual</h2></div>
    <div class="card-body">
      <div class="field"><label for="b-name">Nombre de la comunidad</label><input id="b-name" name="nombre" value="{{ $tenant['name'] }}"></div>
      <div class="field"><label>Logo</label><label class="dropzone" style="display:block"><x-icon name="upload" /> <span data-file-name>Sube tu logotipo (PNG o SVG)</span><input type="file" accept="image/*" hidden></label></div>
      <div class="field"><label for="b-color">Color principal</label>
        <input id="b-color" type="color" name="color" value="{{ $tenant['color'] }}">
        <div class="swatches mt">@foreach(['#0f766e','#2563eb','#9333ea','#dc2626','#ea580c','#0891b2','#111827'] as $c)<span class="swatch" data-color="{{ $c }}" style="background:{{ $c }}" role="button" aria-label="Color {{ $c }}"></span>@endforeach</div></div>
      <div class="field"><label>Favicon</label><label class="dropzone" style="display:block"><x-icon name="image" /> <span data-file-name>Sube un ícono cuadrado (32×32 o mayor)</span><input type="file" accept="image/*" hidden></label></div>
      <div class="field"><label for="b-sub">Subdominio</label>
        <div style="display:flex;align-items:center;gap:.4rem"><input id="b-sub" name="subdominio" value="{{ $tenant['subdomain'] }}"><span class="muted" style="white-space:nowrap">.netcloudone.com</span></div></div>
      <div class="form-actions"><button type="reset" class="btn btn-outline">Descartar</button><button class="btn">Guardar cambios</button></div>
    </div>
  </form>

  <div>
    <h3>Vista previa en vivo</h3>
    <div class="preview" data-preview style="--brand: {{ $tenant['color'] }}">
      <div class="preview-bar"><span class="tenant-logo" style="background:rgba(255,255,255,.25)" data-pv-logo>{{ $tenant['initials'] }}</span><b data-pv-name>{{ $tenant['name'] }}</b><x-icon name="bell" /></div>
      <div class="preview-body">
        <div class="card"><div class="cell"><x-avatar name="Ana Beltrán" size="sm" /><div class="small"><b>Ana Beltrán</b><br><span class="muted">Hace 2 h</span></div></div>
          <p class="small" style="margin:.6rem 0">Así se verá el feed con los colores de tu comunidad.</p>
          <button class="btn btn-sm" type="button">Confirmar asistencia</button></div>
        <div class="card"><span class="badge brand">Comunicado</span> <span class="small">Bienvenidos a la comunidad</span></div>
      </div>
    </div>
    <p class="muted small mt"><x-icon name="globe" /> <span data-pv-url>{{ $tenant['subdomain'] }}.netcloudone.com</span></p>
  </div>
</div>
@endsection
