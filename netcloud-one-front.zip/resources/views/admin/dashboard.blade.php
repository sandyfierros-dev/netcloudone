@extends('layouts.admin')
@section('title', 'Inicio')
@section('content')
<div class="grid g4 mb">
  <div class="card stat"><div class="lbl"><x-icon name="users" /> Miembros activos</div><div class="num">128</div></div>
  <div class="card stat"><div class="lbl"><x-icon name="mail" /> Invitaciones pendientes</div><div class="num">7</div></div>
  <div class="card stat"><div class="lbl"><x-icon name="calendar" /> Próximos eventos</div><div class="num">4</div></div>
  <div class="card stat"><div class="lbl"><x-icon name="layout" /> Publicaciones recientes</div><div class="num">23</div></div>
</div>

<h2>Accesos directos</h2>
<div class="grid g4 mb">
  <a class="shortcut" href="{{ route('admin.members') }}"><x-icon name="plus" /> Invitar usuario</a>
  <a class="shortcut" href="{{ route('admin.events.create') }}"><x-icon name="calendar" /> Crear evento</a>
  <a class="shortcut" href="{{ route('admin.feed') }}"><x-icon name="layout" /> Publicar anuncio</a>
  <a class="shortcut" href="{{ route('admin.branding') }}"><x-icon name="droplet" /> Personalizar marca</a>
</div>

<div class="grid g2" style="align-items:start">
  <div class="card">
    <div class="card-head"><h3>Próximos eventos</h3><a class="small" href="{{ route('admin.events') }}">Ver todos</a></div>
    <div class="card-body">
      @foreach($events as $e)
        <div class="mini"><div class="date-pill" style="width:48px;padding:.3rem 0"><b style="font-size:1.1rem">{{ $e['day'] }}</b><span>{{ $e['month'] }}</span></div>
          <div class="small" style="flex:1"><b>{{ $e['title'] }}</b><br><span class="muted">{{ $e['going'] }}/{{ $e['cap'] }} confirmados</span></div></div>
      @endforeach
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h3>Actividad reciente</h3><a class="small" href="{{ route('admin.feed') }}">Moderar</a></div>
    <div class="card-body">
      @foreach($posts as $p)
        <div class="mini"><x-avatar :name="$p['author']" size="sm" /><div class="small"><b>{{ $p['author'] }}</b> publicó<br><span class="muted">{{ \Illuminate\Support\Str::limit($p['text'], 70) }}</span></div></div>
      @endforeach
    </div>
  </div>
</div>
@endsection
