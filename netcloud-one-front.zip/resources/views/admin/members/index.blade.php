@extends('layouts.admin')
@section('title', 'Miembros')
@section('content')
<div class="page-head">
  <p class="muted">Gestiona la membresía de las personas en tu empresa.</p>
  <div>
    <button class="btn btn-outline" data-modal-open="modal-add"><x-icon name="user" /> Dar de alta</button>
    <button class="btn" data-modal-open="modal-invite"><x-icon name="mail" /> Invitar por correo</button>
  </div>
</div>
<div class="toolbar">
  <div class="input-icon grow"><x-icon name="search" /><input type="search" placeholder="Buscar miembro…" data-filter=".member-row" aria-label="Buscar miembro"></div>
  <select data-filter-select=".member-row" aria-label="Filtrar por estado"><option value="">Todos los estados</option><option>Activo</option><option>Invitado</option><option>Suspendido</option></select>
</div>
<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Miembro</th><th>Rol</th><th>Estado</th><th>Socio desde</th><th></th></tr></thead>
      <tbody>
        @foreach($members as $m)
          <tr class="member-row" data-group="{{ $m['status'] }}">
            <td><div class="cell"><x-avatar :name="$m['name']" /><div style="line-height:1.2"><b>{{ $m['name'] }}</b><br><small class="muted">{{ $m['email'] }}</small></div></div></td>
            <td><select style="width:auto;padding:.3rem .5rem" aria-label="Rol"><option {{ $m['rol'] === 'Usuario' ? 'selected' : '' }}>Usuario</option><option {{ $m['rol'] === 'Administrador' ? 'selected' : '' }}>Administrador</option></select></td>
            <td><x-status :value="$m['status']" /></td>
            <td>{{ $m['since'] }}</td>
            <td><div class="actions">
              @if($m['status'] === 'Suspendido')<button class="btn btn-outline btn-sm">Reactivar</button>
              @else<button class="btn btn-outline btn-sm" data-modal-open="modal-off" title="Desactivar membresía"><x-icon name="lock" /> Desactivar</button>@endif
            </div></td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <x-pagination />
</div>

{{-- Invitar por correo (CU-B04) --}}
<div class="modal-bg" id="modal-invite"><div class="modal">
  <h2>Invitar por correo</h2><p class="muted small">Enviaremos una invitación para unirse a la comunidad.</p>
  <div class="field"><label>Correos (uno por línea)</label><textarea placeholder="persona@correo.com"></textarea></div>
  <div class="field"><label>Rol</label><select><option>Usuario</option><option>Administrador</option></select></div>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Cancelar</button><button class="btn" data-modal-close>Enviar invitaciones</button></div>
</div></div>

{{-- Dar de alta (CU-B05) --}}
<div class="modal-bg" id="modal-add"><div class="modal">
  <h2>Dar de alta usuario</h2><p class="muted small">Si la persona ya tiene cuenta global, solo se le agrega la membresía.</p>
  <div class="field"><label>Nombre completo</label><input></div>
  <div class="field"><label>Correo electrónico</label><input type="email"></div>
  <div class="grid g2"><div class="field"><label>Rol</label><select><option>Usuario</option><option>Administrador</option></select></div>
  <div class="field"><label>Fecha de socio</label><input type="date"></div></div>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Cancelar</button><button class="btn" data-modal-close>Dar de alta</button></div>
</div></div>

{{-- Desactivar membresía (CU-B08) --}}
<div class="modal-bg" id="modal-off"><div class="modal">
  <h2>¿Desactivar membresía?</h2>
  <p class="muted">La persona perderá el acceso a esta empresa. Su cuenta global y sus otras membresías no se eliminan.</p>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Cancelar</button><button class="btn btn-danger" data-modal-close>Desactivar</button></div>
</div></div>
@endsection
