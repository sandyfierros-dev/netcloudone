@extends('layouts.admin')
@section('title', 'Notificaciones')
@section('content')
<form method="post" action="#">@csrf
  <div class="card mb">
    <div class="card-head"><h2>Avisos y canales</h2></div>
    <div class="card-body">
      <p class="muted small">Define qué avisos se envían y por qué canal (los envíos externos se ejecutan con n8n).</p>
      @foreach(['Nuevo evento', 'Nueva publicación fijada', 'Invitación a la comunidad', 'Recordatorio de evento'] as $a)
        <div class="setting-row">
          <p><b>{{ $a }}</b></p>
          <div class="channels">
            <label class="check small"><input type="checkbox" checked> En la plataforma</label>
            <label class="check small"><input type="checkbox" {{ $loop->index % 2 === 0 ? 'checked' : '' }}> Correo</label>
            <label class="check small"><input type="checkbox" {{ $loop->index === 0 ? 'checked' : '' }}> WhatsApp</label>
          </div>
        </div>
      @endforeach
    </div>
  </div>

  <div class="card mb">
    <div class="card-head"><h2>Plantillas de mensajes</h2></div>
    <div class="card-body">
      <div class="field"><label for="t-sel">Plantilla</label><select id="t-sel"><option>Nuevo evento</option><option>Invitación a la comunidad</option><option>Recordatorio de evento</option></select></div>
      <div class="field"><label for="t-sub">Asunto</label><input id="t-sub" value="Nuevo evento en @{{nombre_comunidad}}: @{{titulo_evento}}"></div>
      <div class="field"><label for="t-body">Mensaje</label><textarea id="t-body" rows="5">Hola @{{nombre}}, tenemos un nuevo evento: @{{titulo_evento}} el @{{fecha}} en @{{lugar}}. ¡Confirma tu asistencia!</textarea>
        <div class="hint">Variables disponibles: @{{nombre}}, @{{nombre_comunidad}}, @{{titulo_evento}}, @{{fecha}}, @{{lugar}}</div></div>
    </div>
  </div>
  <div class="form-actions"><button class="btn">Guardar configuración</button></div>
</form>
@endsection
