@extends('layouts.admin')
@section('title', 'Chat')
@section('content')
<div class="page-head">
  <div class="alert" style="margin:0"><x-icon name="lock" /><span>Los mensajes privados entre usuarios no se muestran a los administradores.</span></div>
  <button class="btn" data-modal-open="modal-chan"><x-icon name="plus" /> Crear canal</button>
</div>
<div class="tabs" data-tabs><button class="tab on" data-tab="chan">Canales y grupos</button><button class="tab" data-tab="rep">Mensajes reportados <span class="badge bad">3</span></button></div>
<div>
  <div class="tab-panel on" data-panel="chan">
    <div class="card">
      @foreach([['Anuncios', 128, false], ['Tecnología', 24, false], ['Eventos', 61, false], ['Proyecto 2025', 9, true]] as $c)
        <div class="channel"><span class="ch-ic"><x-icon name="{{ $c[2] ? 'archive' : 'hash' }}" /></span>
          <div style="flex:1"><b>{{ $c[0] }}</b> @if($c[2])<span class="badge">Archivado</span>@endif<br><small class="muted">{{ $c[1] }} miembros</small></div>
          <button class="btn btn-outline btn-sm"><x-icon name="users" /> Miembros</button>
          <button class="btn btn-outline btn-sm"><x-icon name="archive" /> {{ $c[2] ? 'Restaurar' : 'Archivar' }}</button></div>
      @endforeach
    </div>
  </div>
  <div class="tab-panel" data-panel="rep">
    <div class="card">
      @foreach([['Iván Olvera', '#Anuncios', 'Mensaje con contenido ofensivo.'], ['Rodrigo Téllez', '#Tecnología', 'Spam repetido en el canal.'], ['Karla Mejía', '#Eventos', 'Publicidad no autorizada.']] as $r)
        <div class="channel"><x-avatar :name="$r[0]" /><div style="flex:1"><b>{{ $r[0] }}</b> <span class="badge">{{ $r[1] }}</span><br><span class="muted small">{{ $r[2] }}</span></div>
          <button class="btn btn-outline btn-sm">Ignorar</button><button class="btn btn-danger btn-sm"><x-icon name="trash" /> Eliminar mensaje</button></div>
      @endforeach
    </div>
  </div>
</div>

<div class="modal-bg" id="modal-chan"><div class="modal">
  <h2>Crear canal</h2>
  <div class="field"><label>Nombre del canal</label><input placeholder="p. ej. Marketing"></div>
  <div class="field"><label>Miembros</label><select multiple style="height:130px">@foreach($members as $m)<option>{{ $m['name'] }}</option>@endforeach</select><div class="hint">Mantén Ctrl/Cmd para elegir varios.</div></div>
  <div class="form-actions"><button class="btn btn-outline" data-modal-close>Cancelar</button><button class="btn" data-modal-close>Crear canal</button></div>
</div></div>
@endsection
