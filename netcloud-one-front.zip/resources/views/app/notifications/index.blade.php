@extends('layouts.company')
@section('title', 'Notificaciones')
@section('content')
<div class="narrow">
  <div class="page-head"><h1>Notificaciones</h1><button class="btn btn-outline btn-sm"><x-icon name="check" /> Marcar todo como leído</button></div>
  <div class="tabs" data-tabs>
    <button class="tab on" data-tab="list">Recibidas</button>
    <button class="tab" data-tab="prefs">Preferencias</button>
  </div>
  <div>
    <div class="tab-panel on" data-panel="list">
      <div class="card">
        @foreach($notifications as $n)
          <div class="notif-item {{ $n['unread'] ? 'unread' : '' }}" style="padding:.9rem 1.2rem;{{ $loop->first ? '' : 'border-top:1px solid var(--line);border-radius:0' }}">
            <span class="avatar sm" style="background:var(--brand-soft);color:var(--brand)"><x-icon name="{{ $n['icon'] }}" /></span>
            <div style="flex:1">{{ $n['text'] }}<br><small class="muted">{{ $n['time'] }}</small></div>
            @if($n['unread'])<span class="dot ok" style="background:var(--brand);align-self:center"></span>@endif
          </div>
        @endforeach
      </div>
    </div>
    <div class="tab-panel" data-panel="prefs">
      <form class="card card-body" method="post" action="#">@csrf
        <p class="muted small">Elige qué avisos quieres recibir y por qué canal.</p>
        @foreach(['Nuevos eventos', 'Publicaciones fijadas', 'Comentarios en mis publicaciones', 'Recordatorios de eventos'] as $item)
          <div class="setting-row">
            <p><b>{{ $item }}</b></p>
            <div class="channels">
              <label class="check small"><input type="checkbox" checked> En la plataforma</label>
              <label class="check small"><input type="checkbox" {{ $loop->odd ? 'checked' : '' }}> Correo</label>
              <label class="check small"><input type="checkbox"> WhatsApp</label>
            </div>
          </div>
        @endforeach
        <div class="form-actions"><button class="btn">Guardar preferencias</button></div>
      </form>
    </div>
  </div>
</div>
@endsection
