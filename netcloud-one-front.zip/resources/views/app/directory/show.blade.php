@extends('layouts.company')
@section('title', $m['name'])
@section('content')
<div class="narrow">
  <a href="{{ route('app.directory') }}" class="btn btn-ghost btn-sm mb"><x-icon name="arrow-left" /> Directorio</a>
  <div class="card">
    <div class="profile-hero">
      <x-avatar :name="$m['name']" size="xl" />
      <div>
        <h1>{{ $m['name'] }}</h1>
        <p class="muted">{{ $m['title'] }} · {{ $m['area'] }}</p>
        <a class="btn" href="{{ route('app.chat') }}"><x-icon name="message" /> Enviar mensaje</a>
      </div>
    </div>
    <div class="card-body" style="border-top:1px solid var(--line)">
      <h3>Información de contacto</h3>
      <ul class="info-list">
        <li><x-icon name="mail" /> {{ $m['email'] }}</li>
        <li><x-icon name="phone" /> {{ $m['phone'] }}</li>
        <li><x-icon name="building" /> Área: {{ $m['area'] }}</li>
        <li><x-icon name="calendar" /> Socio desde {{ $m['since'] }}</li>
      </ul>
    </div>
  </div>
</div>
@endsection
