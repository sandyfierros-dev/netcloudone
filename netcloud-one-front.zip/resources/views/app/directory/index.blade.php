@extends('layouts.company')
@section('title', 'Directorio')
@section('content')
<div class="page-head"><div><h1>Directorio</h1><p class="muted">Conoce a los miembros de tu comunidad.</p></div></div>
<div class="toolbar">
  <div class="input-icon grow"><x-icon name="search" /><input type="search" placeholder="Buscar por nombre, cargo o área…" data-filter=".member-item" aria-label="Buscar miembros"></div>
  <select data-filter-select=".member-item" aria-label="Filtrar por área">
    <option value="">Todas las áreas</option>
    @foreach($areas as $a)<option>{{ $a }}</option>@endforeach
  </select>
</div>
<div class="grid g-auto">
  @foreach($members as $m)
    @continue($m['status'] !== 'Activo')
    <a class="card member-card member-item" data-group="{{ $m['area'] }}" href="{{ route('app.directory.show', $m['id']) }}">
      <x-avatar :name="$m['name']" />
      <h3>{{ $m['name'] }}</h3>
      <div class="muted small">{{ $m['title'] }}</div>
      <span class="badge mt">{{ $m['area'] }}</span>
    </a>
  @endforeach
</div>
@endsection
