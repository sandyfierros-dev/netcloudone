@extends('layouts.company')
@section('title', 'Inicio')
@section('content')
<div class="feed-layout">
  <section>
    {{-- Crear publicación (CU-C14, CU-C22) --}}
    <form class="card composer" method="post" action="#" enctype="multipart/form-data">@csrf
      <div class="composer-row">
        <x-avatar name="Zamiel Hernández" />
        <textarea name="body" placeholder="¿Qué quieres compartir?"></textarea>
      </div>
      <div class="composer-tools">
        <div>
          <label class="btn btn-ghost btn-sm" style="cursor:pointer"><x-icon name="image" /> Foto<input type="file" accept="image/*" hidden></label>
          <label class="btn btn-ghost btn-sm" style="cursor:pointer"><x-icon name="paperclip" /> Archivo<input type="file" hidden></label>
        </div>
        <button class="btn btn-sm"><x-icon name="send" /> Publicar</button>
      </div>
    </form>

    {{-- Publicaciones --}}
    @foreach($posts as $p)
      <article class="card post {{ $p['pinned'] ? 'pinned' : '' }}">
        <div class="post-head">
          <x-avatar :name="$p['author']" />
          <div class="who"><b>{{ $p['author'] }}</b> @if($p['official'])<span class="badge brand">Comunicado</span>@endif<br><small class="muted">{{ $p['title'] }} · {{ $p['time'] }}</small></div>
          @if($p['pinned'])<span class="badge warn"><x-icon name="bookmark" /> Fijada</span>@endif
        </div>
        <div class="post-body">{{ $p['text'] }}</div>
        @if($p['image'])<div class="post-img">{{ $p['image'] }}</div>@endif
        <div class="post-bar">
          <button type="button" data-like class="{{ $p['liked'] ? 'on' : '' }}"><x-icon name="heart" /> <span class="n">{{ $p['likes'] }}</span></button>
          <button type="button" data-thread="thread-{{ $p['id'] }}"><x-icon name="message" /> {{ count($p['comments']) }} comentarios</button>
        </div>
        <div class="thread {{ $p['id'] === 1 ? 'open' : '' }}" id="thread-{{ $p['id'] }}">
          @foreach($p['comments'] as $c)
            <div class="comment"><x-avatar :name="$c[0]" size="sm" /><div class="bubble"><b>{{ $c[0] }}</b><br>{{ $c[1] }}</div></div>
          @endforeach
          <form class="reply" data-reply>
            <input placeholder="Escribe una respuesta…" aria-label="Responder">
            <button class="btn btn-icon" aria-label="Enviar"><x-icon name="send" /></button>
          </form>
        </div>
      </article>
    @endforeach
  </section>

  <aside>
    <div class="card side-card">
      <h3>Próximos eventos</h3>
      @foreach($events as $e)
        <a class="mini" href="{{ route('app.events.show', $e['id']) }}" style="color:inherit;text-decoration:none">
          <div class="date-pill" style="width:48px;padding:.3rem 0"><b style="font-size:1.1rem">{{ $e['day'] }}</b><span>{{ $e['month'] }}</span></div>
          <div class="small"><b>{{ $e['title'] }}</b><br><span class="muted">{{ $e['time'] }}</span></div>
        </a>
      @endforeach
      <a class="small" href="{{ route('app.events') }}">Ver todos →</a>
    </div>
  </aside>
</div>
@endsection
