@extends('layouts.company')
@section('title', 'Mi perfil')
@section('content')
<div class="narrow">
  <div class="card card-body cell mb" style="gap:1.2rem">
    <x-avatar :name="$user['name']" size="lg" />
    <div><h1 style="margin:0">{{ $user['name'] }}</h1><span class="muted">{{ $user['role'] }}</span></div>
  </div>

  <form method="post" action="#">@csrf
    <div class="card mb">
      <div class="card-head"><h2>Datos personales</h2></div>
      <div class="card-body">
        <div class="field"><label for="p-email">Correo electrónico</label><input id="p-email" type="email" name="email" value="{{ $user['email'] }}"></div>
        <div class="field"><label for="p-phone">Teléfono</label><input id="p-phone" name="phone" value="{{ $user['phone'] }}"></div>
        <div class="grid g2">
          <div class="field"><label for="p-cargo">Cargo</label><input id="p-cargo" name="cargo" value="Desarrollador"></div>
          <div class="field"><label for="p-area">Área</label><input id="p-area" name="area" value="Tecnología"></div>
        </div>
        <div class="field">
          <label for="p-since"><x-icon name="lock" /> Fecha de socio</label>
          <input id="p-since" value="{{ $user['since'] }}" disabled>
          <div class="hint">Este dato es de solo lectura.</div>
        </div>
      </div>
    </div>

    <div class="card mb">
      <div class="card-head"><h2>Cambiar contraseña</h2></div>
      <div class="card-body">
        <div class="field"><label for="c-now">Contraseña actual</label><input id="c-now" type="password" name="current_password" autocomplete="current-password"></div>
        <div class="grid g2">
          <div class="field"><label for="c-new">Nueva contraseña</label><input id="c-new" type="password" name="password" autocomplete="new-password"></div>
          <div class="field"><label for="c-new2">Confirmar contraseña</label><input id="c-new2" type="password" name="password_confirmation" autocomplete="new-password"></div>
        </div>
      </div>
    </div>
    <div class="form-actions"><button class="btn">Guardar cambios</button></div>
  </form>
</div>
@endsection
