@extends('layouts.company')
@section('title', 'Eventos')
@section('content')
<div class="page-head"><div><h1>Eventos</h1><p class="muted">Próximos encuentros de tu comunidad.</p></div></div>
<div class="tabs" data-tabs>
  <button class="tab on" data-tab="next">Próximos</button>
  <button class="tab" data-tab="past">Pasados</button>
</div>
<div>
  <div class="tab-panel on" data-panel="next">
    <div class="grid" style="gap:.8rem">
      @foreach($events as $e)
        @continue($e['status'] === 'Cancelado')
        <a href="{{ route('app.events.show', $e['id']) }}" class="card event-card">
          <div class="date-pill"><b>{{ $e['day'] }}</b><span>{{ $e['month'] }}</span></div>
          <div style="flex:1;min-width:0">
            <h3>{{ $e['title'] }}</h3>
            <div class="muted small"><x-icon name="pin" /> {{ $e['place'] }} · <x-icon name="clock" /> {{ $e['time'] }}</div>
          </div>
          <div class="right small"><span class="badge {{ $e['mode'] === 'Virtual' ? 'info' : '' }}">{{ $e['mode'] }}</span><br><span class="muted">{{ $e['going'] }} asistirán</span></div>
        </a>
      @endforeach
    </div>
  </div>
  <div class="tab-panel" data-panel="past">
    <div class="card card-body center muted"><x-icon name="calendar" /> Aún no hay eventos pasados.</div>
  </div>
</div>
@endsection
