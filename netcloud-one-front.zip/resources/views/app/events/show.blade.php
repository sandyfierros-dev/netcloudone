@extends('layouts.company')
@section('title', $e['title'])
@section('content')
<div class="narrow">
  <a href="{{ route('app.events') }}" class="btn btn-ghost btn-sm mb"><x-icon name="arrow-left" /> Eventos</a>
  <article class="card">
    <div class="cover"><x-icon name="calendar" /></div>
    <div class="card-body">
      <h1>{{ $e['title'] }}</h1>
      <div class="detail-meta">
        <div><x-icon name="calendar" /><span><b>Fecha</b><br>{{ $e['date'] }}</span></div>
        <div><x-icon name="clock" /><span><b>Hora</b><br>{{ $e['time'] }}</span></div>
        <div><x-icon name="pin" /><span><b>Ubicación</b><br>{{ $e['place'] }}</span></div>
        <div><x-icon name="user" /><span><b>Organizador</b><br>{{ $e['organizer'] }}</span></div>
      </div>
      <p>{{ $e['desc'] }}</p>

      <div class="mt mb">
        <b class="small">{{ $e['going'] }} personas asistirán</b>
        <div class="stack mt">@foreach($members as $m)<x-avatar :name="$m['name']" size="sm" />@endforeach</div>
      </div>

      <div data-rsvp>
        <div data-rsvp-ask>
          <button class="btn" data-rsvp-yes><x-icon name="check" /> Confirmar asistencia</button>
        </div>
        <div class="rsvp-ok hidden" data-rsvp-ok>
          <x-icon name="check" /> Asistencia confirmada
          <button class="btn btn-outline btn-sm" style="margin-left:auto" data-rsvp-no>Cancelar asistencia</button>
        </div>
      </div>
    </div>
  </article>
</div>
@endsection
