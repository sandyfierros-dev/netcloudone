@extends('layouts.company')
@section('title', 'Chat')
@section('content')
<div class="card chat">
  {{-- Lista de conversaciones --}}
  <div class="chat-list">
    <div class="chat-search"><div class="input-icon"><x-icon name="search" /><input type="search" placeholder="Buscar conversación" data-filter=".conv" aria-label="Buscar conversación"></div></div>
    @foreach($conversations as $c)
      <div class="conv {{ $loop->first ? 'on' : '' }}" data-name="{{ $c['name'] }}">
        @if($c['type'] === 'canal')<span class="avatar" style="background:var(--brand-soft);color:var(--brand)"><x-icon name="hash" /></span>@else<x-avatar :name="$c['name']" />@endif
        <div class="mid"><b>{{ $c['name'] }}</b><p>{{ $c['last'] }}</p></div>
        <div class="end">{{ $c['time'] }}@if($c['unread'])<br><span class="unread-n">{{ $c['unread'] }}</span>@endif</div>
      </div>
    @endforeach
  </div>

  {{-- Conversación activa --}}
  <div class="chat-win">
    <div class="chat-head">
      <button class="icon-btn chat-back" aria-label="Volver"><x-icon name="arrow-left" /></button>
      <x-avatar name="Ana Beltrán" />
      <div style="line-height:1.2"><b data-chat-title>Ana Beltrán</b><br><small class="muted">En línea</small></div>
    </div>
    <div class="msgs">
      <div class="day-sep">Hoy</div>
      @foreach($messages as $m)
        <div class="bubble-msg {{ $m['me'] ? 'me' : '' }}"><span>{{ $m['text'] }}</span><time>{{ $m['time'] }}</time></div>
      @endforeach
    </div>
    <form class="chat-input" data-chat-form>
      <input placeholder="Escribe un mensaje…" aria-label="Mensaje">
      <button class="btn btn-icon" aria-label="Enviar"><x-icon name="send" /></button>
    </form>
  </div>
</div>
@endsection
