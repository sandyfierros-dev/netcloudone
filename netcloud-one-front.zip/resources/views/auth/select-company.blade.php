@extends('layouts.auth')
@section('title', 'Elige tu empresa')
@section('content')
<div style="width:100%;max-width:820px">
  <div class="center mb">
    <h1>Hola, {{ explode(' ', $user['name'])[0] }} 👋</h1>
    <p class="muted">Elige la comunidad a la que quieres entrar.</p>
  </div>
  <div class="grid g-auto">
    @foreach($companies as $c)
      @continue($c['status'] === 'Suspendida')
      <a href="{{ $c['role'] === 'Administrador' ? route('admin.dashboard') : route('app.feed') }}" class="card member-card">
        <span class="tenant-logo lg" style="background:{{ $c['color'] }};margin:0 auto .7rem">{{ mb_strtoupper(mb_substr($c['name'], 0, 2)) }}</span>
        <h3>{{ $c['name'] }}</h3>
        <span class="badge {{ $c['role'] === 'Administrador' ? 'brand' : '' }}">{{ $c['role'] }}</span>
      </a>
    @endforeach
  </div>
  <form method="post" action="{{ route('logout') }}" class="center mt">@csrf<button class="btn btn-ghost btn-sm"><x-icon name="log-out" /> Cerrar sesión</button></form>
</div>
@endsection
