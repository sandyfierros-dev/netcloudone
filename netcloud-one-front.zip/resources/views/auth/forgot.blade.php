@extends('layouts.auth')
@section('title', 'Recuperar contraseña')
@section('content')
<div class="card auth-card">
  @if($sent)
    <div class="center">
      <div class="status-icon"><x-icon name="mail" /></div>
      <h1>Enviamos un enlace a tu correo</h1>
      <p class="muted">Revisa tu bandeja de entrada y sigue las instrucciones para restablecer tu contraseña. El enlace vence en 60 minutos.</p>
      <div class="alert ok"><x-icon name="check" /><span>Si no lo ves, revisa tu carpeta de spam.</span></div>
      <a class="btn btn-outline btn-block" href="{{ route('login') }}"><x-icon name="arrow-left" /> Volver al inicio de sesión</a>
    </div>
  @else
    <h1>Recuperar contraseña</h1>
    <p class="muted small">Escribe tu correo y te enviaremos un enlace para crear una nueva contraseña.</p>
    <form method="post" action="#">@csrf
      <div class="field"><label for="f-email">Correo electrónico</label>
        <div class="input-icon"><x-icon name="mail" /><input id="f-email" type="email" name="email" placeholder="tu@correo.com" required autofocus></div></div>
      <a class="btn btn-block" href="{{ route('password.sent') }}">Enviar instrucciones</a>
    </form>
    <a class="auth-link" href="{{ route('login') }}">← Volver al inicio de sesión</a>
  @endif
</div>
@endsection
