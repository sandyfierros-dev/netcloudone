@extends('layouts.auth')
@section('title', 'Acceso')
@section('content')
<div class="card auth-card">
  <div class="tabs" data-tabs>
    <button type="button" class="tab {{ $tab === 'login' ? 'on' : '' }}" data-tab="login">Iniciar sesión</button>
    <button type="button" class="tab {{ $tab === 'register' ? 'on' : '' }}" data-tab="register">Crear cuenta</button>
  </div>

  <div class="tab-panels">
    {{-- Iniciar sesión --}}
    <div class="tab-panel {{ $tab === 'login' ? 'on' : '' }}" data-panel="login">
      <h1>Bienvenido de nuevo</h1>
      <p class="muted small">Entra con tu cuenta de Netcloud One.</p>
      <form method="post" action="#">@csrf
        <div class="field"><label for="l-email">Correo electrónico</label>
          <div class="input-icon"><x-icon name="mail" /><input id="l-email" type="email" name="email" placeholder="tu@correo.com" required autofocus></div></div>
        <div class="field"><label for="l-pass">Contraseña</label>
          <div class="input-icon"><x-icon name="lock" /><input id="l-pass" type="password" name="password" placeholder="••••••••" required></div></div>
        <div class="setting-row" style="border:0;padding:0 0 1rem">
          <label class="check small"><input type="checkbox" name="remember"> Recordarme</label>
          <a class="small" href="{{ route('password.request') }}">¿Olvidaste tu contraseña?</a>
        </div>
        <a class="btn btn-block" href="{{ route('company.select') }}">Iniciar sesión</a>
      </form>
    </div>

    {{-- Crear cuenta --}}
    <div class="tab-panel {{ $tab === 'register' ? 'on' : '' }}" data-panel="register">
      <h1>Crea tu cuenta</h1>
      <div class="alert"><x-icon name="info" /><span>Tu cuenta es <b>global</b>: te sirve para todas las empresas a las que pertenezcas.</span></div>
      <form method="post" action="#">@csrf
        <div class="field"><label for="r-name">Nombre completo</label>
          <div class="input-icon"><x-icon name="user" /><input id="r-name" name="name" placeholder="Tu nombre" required></div></div>
        <div class="field"><label for="r-email">Correo electrónico</label>
          <div class="input-icon"><x-icon name="mail" /><input id="r-email" type="email" name="email" placeholder="tu@correo.com" required></div></div>
        <div class="field"><label for="r-pass">Contraseña</label>
          <div class="input-icon"><x-icon name="lock" /><input id="r-pass" type="password" name="password" placeholder="Mínimo 8 caracteres" required></div></div>
        <div class="field"><label for="r-pass2">Confirmar contraseña</label>
          <div class="input-icon"><x-icon name="lock" /><input id="r-pass2" type="password" name="password_confirmation" placeholder="Repite tu contraseña" required></div></div>
        <button class="btn btn-block">Crear cuenta</button>
      </form>
    </div>
  </div>
</div>
<p class="small muted mt">¿Administras una comunidad? <a href="{{ route('login.admin') }}">Acceso de administrador de empresa</a> · <a href="{{ route('login.global') }}">Administrador global</a></p>
@endsection
