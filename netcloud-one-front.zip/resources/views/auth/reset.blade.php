@extends('layouts.auth')
@section('title', 'Nueva contraseña')
@section('content')
<div class="card auth-card">
  <h1>Crea una nueva contraseña</h1>
  <p class="muted small">Elige una contraseña segura de al menos 8 caracteres.</p>
  <form method="post" action="#">@csrf
    <div class="field"><label for="p1">Nueva contraseña</label>
      <div class="input-icon"><x-icon name="lock" /><input id="p1" type="password" name="password" required></div></div>
    <div class="field"><label for="p2">Confirmar contraseña</label>
      <div class="input-icon"><x-icon name="lock" /><input id="p2" type="password" name="password_confirmation" required></div></div>
    <a class="btn btn-block" href="{{ route('login') }}">Restablecer contraseña</a>
  </form>
</div>
@endsection
