@extends('layouts.auth')
@section('title', $rol === 'global' ? 'Acceso administrador global' : 'Acceso administrador de empresa')
@section('content')
<div class="card auth-card">
  <span class="badge info" style="margin-bottom:.8rem"><x-icon name="shield" /> {{ $rol === 'global' ? 'Administrador de Netcloud One' : 'Administrador de empresa' }}</span>
  <h1>Iniciar sesión</h1>
  <p class="muted small">{{ $rol === 'global' ? 'Consola para gestionar las empresas de la plataforma.' : 'Ingresa con tu cuenta de administrador para gestionar tu comunidad.' }}</p>
  <form method="post" action="#">@csrf
    <div class="field"><label for="a-email">Correo electrónico</label>
      <div class="input-icon"><x-icon name="mail" /><input id="a-email" type="email" name="email" placeholder="admin@empresa.com" required autofocus></div></div>
    <div class="field"><label for="a-pass">Contraseña</label>
      <div class="input-icon"><x-icon name="lock" /><input id="a-pass" type="password" name="password" placeholder="••••••••" required></div></div>
    <a class="btn btn-block" href="{{ $rol === 'global' ? route('global.dashboard') : route('admin.dashboard') }}">Iniciar sesión</a>
  </form>
  <a class="auth-link" href="{{ route('password.request') }}">¿Olvidaste tu contraseña?</a>
</div>
@endsection
