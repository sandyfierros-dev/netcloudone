@extends('layouts.auth')
@section('title', 'Invitación')
@push('head')<style>:root{--brand: {{ $tenant['color'] }};}</style>@endpush
@section('content')
<div class="card auth-card">
  <div class="center mb">
    <span class="tenant-logo lg" style="margin:0 auto .6rem">{{ $tenant['initials'] }}</span>
    <h1>Te invitaron a {{ $tenant['name'] }}</h1>
    <p class="muted small">Crea tu cuenta de Netcloud One para unirte a la comunidad.</p>
  </div>
  <div class="alert ok"><x-icon name="check" /><span>Invitación vigente. Se asociará a <b>{{ $email }}</b>.</span></div>
  <form method="post" action="#">@csrf
    <div class="field"><label>Correo electrónico</label><input type="email" value="{{ $email }}" disabled></div>
    <div class="field"><label for="i-name">Nombre completo</label><input id="i-name" name="name" required></div>
    <div class="field"><label for="i-p1">Contraseña</label><input id="i-p1" type="password" name="password" required></div>
    <div class="field"><label for="i-p2">Confirmar contraseña</label><input id="i-p2" type="password" name="password_confirmation" required></div>
    <a class="btn btn-block" href="{{ route('company.select') }}">Aceptar invitación y registrarme</a>
  </form>
  <a class="auth-link" href="{{ route('login') }}">¿Ya tienes cuenta? Inicia sesión</a>
</div>
@endsection
