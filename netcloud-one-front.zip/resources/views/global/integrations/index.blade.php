@extends('layouts.global')
@section('title', 'Integraciones')
@section('content')
<p class="muted">Estado de las automatizaciones con n8n disponibles para las empresas.</p>
<div class="grid g2">
  @foreach($integrations as $i)
    <div class="card int-card">
      <div class="int-head">
        <span class="int-logo" style="background:{{ $i['color'] }}">{{ $i['abbr'] }}</span>
        <div style="flex:1"><h3 style="margin:0">{{ $i['name'] }}</h3>
          <span class="small"><span class="dot {{ $i['connected'] ? 'ok' : 'bad' }}"></span> {{ $i['connected'] ? 'Conectado' : 'Desconectado' }}</span></div>
      </div>
      <p class="muted small" style="margin:0">{{ $i['desc'] }}</p>
      <div><button class="btn btn-outline btn-sm" data-modal-open="cfg-{{ $loop->index }}"><x-icon name="sliders" /> Configurar</button></div>
    </div>

    <div class="modal-bg" id="cfg-{{ $loop->index }}">
      <div class="modal">
        <h2>Configurar {{ $i['name'] }}</h2>
        <div class="field"><label>URL del webhook de n8n</label><input placeholder="https://n8n.netcloud.com/webhook/…"></div>
        <div class="field"><label>Clave de API</label><input type="password" placeholder="••••••••••"></div>
        <div class="form-actions">
          <button type="button" class="btn btn-outline" data-modal-close>Cancelar</button>
          <button type="button" class="btn btn-outline"><x-icon name="zap" /> Probar conexión</button>
          <button type="button" class="btn" data-modal-close>Guardar</button>
        </div>
      </div>
    </div>
  @endforeach
</div>
@endsection
