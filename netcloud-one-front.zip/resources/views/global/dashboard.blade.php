@extends('layouts.global')
@section('title', 'Panel principal')
@section('content')
@php
  $total = count($companies);
  $active = collect($companies)->where('status', 'Activa')->count();
  $susp = $total - $active;
@endphp
<div class="grid g3 mb">
  <div class="card stat"><div class="lbl"><x-icon name="building" /> Empresas registradas</div><div class="num">{{ $total }}</div></div>
  <div class="card stat"><div class="lbl"><span class="dot ok"></span> Activas</div><div class="num" style="color:var(--ok)">{{ $active }}</div></div>
  <div class="card stat"><div class="lbl"><span class="dot bad"></span> Suspendidas</div><div class="num" style="color:var(--bad)">{{ $susp }}</div></div>
</div>

<div class="card">
  <div class="card-head"><h2>Empresas recientes</h2><a class="btn btn-outline btn-sm" href="{{ route('global.companies') }}">Ver todas</a></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Empresa</th><th>Administrador</th><th>Fecha de alta</th><th>Estado</th></tr></thead>
      <tbody>
        @foreach(array_slice($companies, 0, 5) as $c)
          <tr>
            <td><div class="cell"><span class="tenant-logo" style="background:{{ $c['color'] }}">{{ mb_strtoupper(mb_substr($c['name'], 0, 2)) }}</span><b>{{ $c['name'] }}</b></div></td>
            <td>{{ $c['admin'] }}</td><td>{{ $c['created'] }}</td><td><x-status :value="$c['status']" /></td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
@endsection
