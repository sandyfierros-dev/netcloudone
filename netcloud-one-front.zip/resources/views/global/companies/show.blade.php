@extends('layouts.global')
@section('title', $c['name'])
@section('content')
<div class="page-head">
  <a href="{{ route('global.companies') }}" class="btn btn-ghost btn-sm"><x-icon name="arrow-left" /> Empresas</a>
  <a class="btn" href="{{ route('global.companies.edit', $c['id']) }}"><x-icon name="edit" /> Editar</a>
</div>
<div class="grid g2" style="align-items:start">
  <div class="card card-body">
    <div class="cell mb"><span class="tenant-logo lg" style="background:{{ $c['color'] }}">{{ mb_strtoupper(mb_substr($c['name'], 0, 2)) }}</span><div><h2 style="margin:0">{{ $c['name'] }}</h2><x-status :value="$c['status']" /></div></div>
    <ul class="info-list">
      <li><x-icon name="mail" /> {{ $c['email'] }}</li>
      <li><x-icon name="phone" /> {{ $c['phone'] }}</li>
      <li><x-icon name="calendar" /> Alta: {{ $c['created'] }}</li>
      <li><x-icon name="users" /> {{ $c['members'] }} miembros</li>
    </ul>
  </div>
  <div class="card card-body">
    <h3>Administrador de la empresa</h3>
    <div class="cell mb"><x-avatar :name="$c['admin']" /><div><b>{{ $c['admin'] }}</b><br><small class="muted">Administrador único</small></div></div>
    <button class="btn btn-outline btn-sm"><x-icon name="mail" /> Reenviar invitación</button>
    <button class="btn btn-outline btn-sm">Reasignar administrador</button>
    <div class="alert warn mt"><x-icon name="info" /><span>Como administrador global no tienes acceso al contenido de la comunidad.</span></div>
  </div>
</div>
@endsection
