{{-- Campos compartidos entre alta y edición. $c = empresa o null --}}
<div class="grid g2 mb" style="align-items:start">
  <div class="card">
    <div class="card-head"><h2>Datos de la empresa</h2></div>
    <div class="card-body">
      <div class="field"><label for="e-name">Nombre de la empresa</label><input id="e-name" name="name" value="{{ $c['name'] ?? '' }}" required></div>
      <div class="field"><label>Logotipo</label>
        <label class="dropzone" style="display:block"><x-icon name="upload" /> <span data-file-name>Arrastra tu logo o haz clic para subirlo</span><input type="file" accept="image/*" hidden></label></div>
      <div class="field"><label for="e-email">Correo de contacto</label><input id="e-email" type="email" name="email" value="{{ $c['email'] ?? '' }}" required></div>
      <div class="field"><label for="e-phone">Teléfono</label><input id="e-phone" name="phone" value="{{ $c['phone'] ?? '' }}"></div>
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h2>Datos del administrador</h2></div>
    <div class="card-body">
      <div class="alert"><x-icon name="info" /><span>Cada empresa tiene un solo administrador.</span></div>
      <div class="field"><label for="a-name">Nombre completo</label><input id="a-name" name="admin_name" value="{{ $c['admin'] ?? '' }}" required></div>
      <div class="field"><label for="a-email">Correo electrónico</label><input id="a-email" type="email" name="admin_email" required></div>
      <div class="field"><label for="a-phone">Teléfono</label><input id="a-phone" name="admin_phone"></div>
      <div class="hint">Se enviará una invitación por correo a este administrador.</div>
    </div>
  </div>
</div>
