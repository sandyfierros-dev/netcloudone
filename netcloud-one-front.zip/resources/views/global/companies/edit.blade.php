@extends('layouts.global')
@section('title', 'Editar empresa')
@section('content')
<form method="post" action="#" enctype="multipart/form-data">@csrf
  @include('global.companies._form', ['c' => $c])

  {{-- Estado de la empresa --}}
  <div class="card mb">
    <div class="card-head"><h2>Estado de la empresa</h2></div>
    <div class="card-body">
      <div class="setting-row" style="border:0;padding:0">
        <div><b>Empresa <span class="badge {{ $c['status'] === 'Activa' ? 'ok' : 'bad' }}" data-state-label>{{ $c['status'] }}</span></b>
          <p class="muted small">Al suspenderla, sus miembros perderán el acceso a la plataforma.</p></div>
        <label class="switch"><input type="checkbox" data-suspend-switch {{ $c['status'] === 'Activa' ? 'checked' : '' }}><span></span></label>
      </div>
    </div>
  </div>
  <div class="form-actions">
    <a class="btn btn-outline" href="{{ route('global.companies') }}">Cancelar</a>
    <button class="btn">Guardar cambios</button>
  </div>
</form>

{{-- Modal de confirmación --}}
<div class="modal-bg" id="modal-suspend">
  <div class="modal">
    <h2>¿Suspender empresa?</h2>
    <p class="muted">Los miembros de <b>{{ $c['name'] }}</b> perderán el acceso a la plataforma hasta que vuelvas a activarla. Sus datos se conservan.</p>
    <div class="form-actions">
      <button type="button" class="btn btn-outline" data-modal-close>Cancelar</button>
      <button type="button" class="btn btn-danger" data-confirm-suspend>Suspender</button>
    </div>
  </div>
</div>
@endsection
