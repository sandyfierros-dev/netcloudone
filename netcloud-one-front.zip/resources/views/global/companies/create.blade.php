@extends('layouts.global')
@section('title', 'Alta de empresa')
@section('content')
<form method="post" action="#" enctype="multipart/form-data">@csrf
  @include('global.companies._form', ['c' => null])
  <div class="form-actions">
    <a class="btn btn-outline" href="{{ route('global.companies') }}">Cancelar</a>
    <button class="btn">Registrar empresa</button>
  </div>
</form>
@endsection
