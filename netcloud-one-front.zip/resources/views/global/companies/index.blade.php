@extends('layouts.global')
@section('title', 'Empresas')
@section('content')
<div class="page-head">
  <p class="muted">Gestiona las empresas (tenants) que usan la plataforma.</p>
  <a class="btn" href="{{ route('global.companies.create') }}"><x-icon name="plus" /> Nueva empresa</a>
</div>
<div class="toolbar">
  <div class="input-icon grow"><x-icon name="search" /><input type="search" placeholder="Buscar empresa por nombre…" data-filter=".company-row" aria-label="Buscar empresa"></div>
  <select data-filter-select=".company-row" aria-label="Filtrar por estado">
    <option value="">Todas</option><option value="Activa">Activa</option><option value="Suspendida">Suspendida</option>
  </select>
</div>
<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Empresa</th><th>Administrador</th><th>Fecha de alta</th><th>Estado</th><th></th></tr></thead>
      <tbody>
        @foreach($companies as $c)
          <tr class="company-row" data-group="{{ $c['status'] }}">
            <td><div class="cell"><span class="tenant-logo" style="background:{{ $c['color'] }}">{{ mb_strtoupper(mb_substr($c['name'], 0, 2)) }}</span><div style="line-height:1.2"><b>{{ $c['name'] }}</b><br><small class="muted">{{ $c['members'] }} miembros</small></div></div></td>
            <td>{{ $c['admin'] }}<br><small class="muted">{{ $c['email'] }}</small></td>
            <td>{{ $c['created'] }}</td>
            <td><x-status :value="$c['status']" /></td>
            <td><div class="actions">
              <a class="btn btn-outline btn-sm" href="{{ route('global.companies.show', $c['id']) }}" title="Ver detalle"><x-icon name="eye" /></a>
              <a class="btn btn-outline btn-sm" href="{{ route('global.companies.edit', $c['id']) }}" title="Editar"><x-icon name="edit" /></a>
            </div></td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <x-pagination />
</div>
@endsection
