@props(['value'])
@php
$map = ['Activa'=>'ok','Activo'=>'ok','Programado'=>'ok','Suspendida'=>'bad','Suspendido'=>'bad','Cancelado'=>'bad','Invitado'=>'warn','Pendiente'=>'warn'];
@endphp
<span class="badge {{ $map[$value] ?? '' }}">{{ $value }}</span>
