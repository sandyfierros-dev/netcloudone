<a href="{{ url('/') }}" class="logo">
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg>
  <span>Netcloud <span style="color:var(--brand)">One</span></span>
</a>
