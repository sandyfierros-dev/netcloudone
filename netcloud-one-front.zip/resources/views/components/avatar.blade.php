@props(['name' => '?', 'size' => ''])
@php
$colors = ['#0f766e','#2563eb','#9333ea','#db2777','#ea580c','#4f46e5','#0891b2','#65a30d'];
$parts = preg_split('/\s+/', trim(preg_replace('/^Canal:\s*/', '', $name)));
$ini = mb_strtoupper(mb_substr($parts[0] ?? '?', 0, 1) . (isset($parts[1]) ? mb_substr($parts[1], 0, 1) : ''));
$bg = $colors[crc32($name) % count($colors)];
@endphp
<span class="avatar {{ $size }}" style="background:{{ $bg }}" title="{{ $name }}">{{ $ini }}</span>
