<div class="pagination">
  <span class="muted small">Mostrando 1–5 de 5 resultados</span>
  <div class="pages"><a href="#">‹</a><a href="#" class="on">1</a><a href="#">2</a><a href="#">3</a><a href="#">›</a></div>
</div>
