<?php

use App\Support\Demo;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Rutas de maquetado (front)
|--------------------------------------------------------------------------
| Devuelven datos de ejemplo de App\Support\Demo. Al conectar el backend,
| mueve cada closure a su controlador y sustituye Demo::* por Eloquent.
*/

Route::redirect('/', '/login');

// ---------- ONE ID (público, sin white-label) ----------
Route::get('/login', fn () => view('auth.access', ['tab' => 'login']))->name('login');
Route::get('/registro', fn () => view('auth.access', ['tab' => 'register']))->name('register');
Route::get('/recuperar-contrasena', fn () => view('auth.forgot', ['sent' => false]))->name('password.request');
Route::get('/recuperar-contrasena/enviado', fn () => view('auth.forgot', ['sent' => true]))->name('password.sent');
Route::get('/restablecer-contrasena/{token}', fn () => view('auth.reset'))->name('password.reset');
Route::get('/invitacion/{token}', fn () => view('auth.invitation', ['tenant' => Demo::tenant(), 'email' => 'zamiel@correo.com']))->name('invitation');
Route::get('/admin-global/login', fn () => view('auth.login-admin', ['rol' => 'global']))->name('login.global');
Route::get('/admin/login', fn () => view('auth.login-admin', ['rol' => 'empresa']))->name('login.admin');
Route::get('/empresas', fn () => view('auth.select-company', ['user' => Demo::user(), 'companies' => Demo::companies()]))->name('company.select');
Route::post('/logout', fn () => redirect()->route('login'))->name('logout');

// ---------- Usuario de empresa (white-label) ----------
Route::prefix('app')->name('app.')->group(function () {
    Route::get('/', fn () => view('app.feed.index', ['posts' => Demo::posts(), 'events' => array_slice(Demo::events(), 0, 3)]))->name('feed');
    Route::get('/directorio', fn () => view('app.directory.index', ['members' => Demo::members(), 'areas' => ['Dirección', 'Ventas', 'Producto', 'Finanzas', 'Comunidad', 'Tecnología', 'Recursos Humanos', 'Operaciones']]))->name('directory');
    Route::get('/directorio/{id}', fn ($id) => view('app.directory.show', ['m' => Demo::members()[(int) $id - 1] ?? Demo::members()[0]]))->name('directory.show');
    Route::get('/eventos', fn () => view('app.events.index', ['events' => Demo::events()]))->name('events');
    Route::get('/eventos/{id}', fn ($id) => view('app.events.show', ['e' => Demo::events()[(int) $id - 1] ?? Demo::events()[0], 'members' => array_slice(Demo::members(), 0, 6)]))->name('events.show');
    Route::get('/chat', fn () => view('app.chat.index', ['conversations' => Demo::conversations(), 'messages' => Demo::messages()]))->name('chat');
    Route::get('/perfil', fn () => view('app.profile.edit', ['user' => Demo::user()]))->name('profile');
    Route::get('/notificaciones', fn () => view('app.notifications.index', ['notifications' => Demo::notifications()]))->name('notifications');
});

// ---------- Administrador global de Netcloud One ----------
Route::prefix('admin-global')->name('global.')->group(function () {
    Route::get('/', fn () => view('global.dashboard', ['companies' => Demo::companies()]))->name('dashboard');
    Route::get('/empresas', fn () => view('global.companies.index', ['companies' => Demo::companies()]))->name('companies');
    Route::get('/empresas/nueva', fn () => view('global.companies.create'))->name('companies.create');
    Route::get('/empresas/{id}', fn ($id) => view('global.companies.show', ['c' => Demo::companies()[(int) $id - 1] ?? Demo::companies()[0]]))->name('companies.show');
    Route::get('/empresas/{id}/editar', fn ($id) => view('global.companies.edit', ['c' => Demo::companies()[(int) $id - 1] ?? Demo::companies()[0]]))->name('companies.edit');
    Route::get('/integraciones', fn () => view('global.integrations.index', ['integrations' => Demo::integrations()]))->name('integrations');
});

// ---------- Administrador de empresa (white-label) ----------
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/', fn () => view('admin.dashboard', ['events' => array_slice(Demo::events(), 0, 3), 'posts' => array_slice(Demo::posts(), 0, 3)]))->name('dashboard');
    Route::get('/miembros', fn () => view('admin.members.index', ['members' => Demo::members()]))->name('members');
    Route::get('/directorio', fn () => view('admin.directory.index', ['members' => Demo::members()]))->name('directory');
    Route::get('/feed', fn () => view('admin.feed.index', ['posts' => Demo::posts()]))->name('feed');
    Route::get('/eventos', fn () => view('admin.events.index', ['events' => Demo::events()]))->name('events');
    Route::get('/eventos/nuevo', fn () => view('admin.events.form', ['e' => null]))->name('events.create');
    Route::get('/eventos/{id}/editar', fn ($id) => view('admin.events.form', ['e' => Demo::events()[(int) $id - 1] ?? Demo::events()[0]]))->name('events.edit');
    Route::get('/eventos/{id}/asistentes', fn ($id) => view('admin.events.attendees', ['e' => Demo::events()[(int) $id - 1] ?? Demo::events()[0], 'members' => array_slice(Demo::members(), 0, 9)]))->name('events.attendees');
    Route::get('/chat', fn () => view('admin.chat.index', ['members' => Demo::members()]))->name('chat');
    Route::get('/personalizacion', fn () => view('admin.branding.index', ['tenant' => Demo::tenant()]))->name('branding');
    Route::get('/notificaciones', fn () => view('admin.notifications.index'))->name('notifications');
});
