/* Netcloud One — interacciones de la interfaz (sin dependencias) */
document.addEventListener('DOMContentLoaded', () => {
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  // Menús desplegables (usuario, notificaciones)
  $$('.menu > [data-menu]').forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    const m = b.parentElement, open = m.classList.contains('open');
    $$('.menu.open').forEach(x => x.classList.remove('open'));
    if (!open) m.classList.add('open');
  }));
  document.addEventListener('click', e => { if (!e.target.closest('.menu')) $$('.menu.open').forEach(x => x.classList.remove('open')); });

  // Barra lateral móvil
  const side = document.querySelector('.sidebar'), scrim = document.querySelector('.scrim');
  $$('[data-burger]').forEach(b => b.addEventListener('click', () => { side?.classList.toggle('open'); scrim?.classList.toggle('open'); }));
  scrim?.addEventListener('click', () => { side.classList.remove('open'); scrim.classList.remove('open'); });

  // Pestañas
  $$('[data-tabs]').forEach(group => {
    const tabs = $$('[data-tab]', group), panels = $$('[data-panel]', group.parentElement);
    const go = name => { tabs.forEach(t => t.classList.toggle('on', t.dataset.tab === name)); panels.forEach(p => p.classList.toggle('on', p.dataset.panel === name)); };
    tabs.forEach(t => t.addEventListener('click', () => go(t.dataset.tab)));
  });

  // Modales
  $$('[data-modal-open]').forEach(b => b.addEventListener('click', () => document.getElementById(b.dataset.modalOpen)?.classList.add('open')));
  $$('[data-modal-close]').forEach(b => b.addEventListener('click', () => b.closest('.modal-bg').classList.remove('open')));
  $$('.modal-bg').forEach(m => m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); }));

  // Mostrar / ocultar contraseña
  $$('[data-eye]').forEach(b => b.addEventListener('click', () => { const i = document.getElementById(b.dataset.eye); i.type = i.type === 'password' ? 'text' : 'password'; }));

  // Hilo de comentarios y reacciones
  $$('[data-thread]').forEach(b => b.addEventListener('click', () => document.getElementById(b.dataset.thread).classList.toggle('open')));
  $$('[data-like]').forEach(b => b.addEventListener('click', () => {
    const n = b.querySelector('.n'), on = b.classList.toggle('on');
    if (n) n.textContent = parseInt(n.textContent) + (on ? 1 : -1);
  }));
  $$('[data-reply]').forEach(f => f.addEventListener('submit', e => {
    e.preventDefault(); const i = f.querySelector('input'); if (!i.value.trim()) return;
    const c = document.createElement('div'); c.className = 'comment';
    c.innerHTML = '<span class="avatar sm">TÚ</span><div class="bubble"><b>Tú</b><br></div>';
    c.querySelector('.bubble').append(document.createTextNode(i.value));
    f.before(c); i.value = '';
  }));

  // Búsqueda en vivo (directorio, listas)
  $$('[data-filter]').forEach(inp => inp.addEventListener('input', () => {
    const q = inp.value.toLowerCase();
    $$(inp.dataset.filter).forEach(el => el.classList.toggle('hidden', !el.textContent.toLowerCase().includes(q)));
  }));
  $$('[data-filter-select]').forEach(sel => sel.addEventListener('change', () => {
    $$(sel.dataset.filterSelect).forEach(el => el.classList.toggle('hidden', sel.value && el.dataset.group !== sel.value));
  }));

  // Confirmar / cancelar asistencia
  const rsvp = document.querySelector('[data-rsvp]');
  if (rsvp) {
    const ask = rsvp.querySelector('[data-rsvp-ask]'), ok = rsvp.querySelector('[data-rsvp-ok]');
    rsvp.querySelector('[data-rsvp-yes]').addEventListener('click', () => { ask.classList.add('hidden'); ok.classList.remove('hidden'); });
    rsvp.querySelector('[data-rsvp-no]').addEventListener('click', () => { ok.classList.add('hidden'); ask.classList.remove('hidden'); });
  }

  // Chat: abrir conversación (móvil) y enviar mensajes
  const chat = document.querySelector('.chat');
  if (chat) {
    $$('.conv', chat).forEach(c => c.addEventListener('click', () => {
      $$('.conv', chat).forEach(x => x.classList.remove('on')); c.classList.add('on');
      chat.classList.add('open-conv');
      const n = c.querySelector('.unread-n'); n?.remove();
      chat.querySelector('[data-chat-title]').textContent = c.dataset.name;
    }));
    chat.querySelector('.chat-back')?.addEventListener('click', () => chat.classList.remove('open-conv'));
    const form = chat.querySelector('[data-chat-form]'), box = chat.querySelector('.msgs');
    form?.addEventListener('submit', e => {
      e.preventDefault(); const i = form.querySelector('input'); if (!i.value.trim()) return;
      const m = document.createElement('div'); m.className = 'bubble-msg me';
      const t = document.createElement('span'); t.textContent = i.value;
      const h = document.createElement('time'); h.textContent = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
      m.append(t, h); box.append(m); i.value = ''; box.scrollTop = box.scrollHeight;
    });
    if (box) box.scrollTop = box.scrollHeight;
  }

  // Vista previa white-label en vivo
  const pv = document.querySelector('[data-preview]');
  if (pv) {
    const set = () => {
      const color = document.querySelector('[name=color]')?.value, name = document.querySelector('[name=nombre]')?.value;
      if (color) pv.style.setProperty('--brand', color);
      if (name) { pv.querySelector('[data-pv-name]').textContent = name; pv.querySelector('[data-pv-logo]').textContent = name.trim().slice(0, 2).toUpperCase(); }
      const sd = document.querySelector('[name=subdominio]'); if (sd) document.querySelector('[data-pv-url]').textContent = (sd.value || 'tu-empresa') + '.netcloudone.com';
    };
    $$('[name=color],[name=nombre],[name=subdominio]').forEach(i => i.addEventListener('input', set));
    $$('.swatch').forEach(s => s.addEventListener('click', () => { document.querySelector('[name=color]').value = s.dataset.color; set(); }));
  }

  // Cargar archivo (nombre de archivo en dropzone)
  $$('.dropzone input[type=file]').forEach(i => i.addEventListener('change', () => { if (i.files[0]) i.closest('.dropzone').querySelector('[data-file-name]').textContent = i.files[0].name; }));

  // Interruptor de empresa Activa/Suspendida con confirmación
  const sw = document.querySelector('[data-suspend-switch]');
  if (sw) sw.addEventListener('change', () => {
    const lbl = document.querySelector('[data-state-label]');
    if (!sw.checked) { sw.checked = true; document.getElementById('modal-suspend').classList.add('open'); }
    else { lbl.textContent = 'Activa'; lbl.className = 'badge ok'; }
  });
  document.querySelector('[data-confirm-suspend]')?.addEventListener('click', () => {
    sw.checked = false; const lbl = document.querySelector('[data-state-label]'); lbl.textContent = 'Suspendida'; lbl.className = 'badge bad';
    document.getElementById('modal-suspend').classList.remove('open');
  });
});
