<?php

namespace App\Support;

/**
 * Datos de ejemplo SOLO para maquetar las vistas.
 * Se reemplazan por consultas Eloquent cuando se conecte el backend.
 */
class Demo
{
    public static function tenant(): array
    {
        return ['name' => 'Club Aurora', 'initials' => 'CA', 'color' => '#0f766e', 'slogan' => 'Comunidad de socios Club Aurora', 'subdomain' => 'aurora'];
    }

    public static function user(): array
    {
        return ['name' => 'Zamiel Hernández', 'email' => 'zamiel@correo.com', 'phone' => '55 1234 5678', 'since' => '14 de marzo de 2024', 'role' => 'Socio'];
    }

    public static function companies(): array
    {
        return [
            ['id' => 1, 'name' => 'Club Aurora', 'admin' => 'Marcela Ríos', 'email' => 'contacto@aurora.mx', 'phone' => '55 4000 1122', 'created' => '12 ene 2026', 'status' => 'Activa', 'role' => 'Administrador', 'members' => 128, 'color' => '#0f766e'],
            ['id' => 2, 'name' => 'Cámara Textil del Valle', 'admin' => 'Luis Ferrer', 'email' => 'info@ctv.mx', 'phone' => '55 5100 2233', 'created' => '03 feb 2026', 'status' => 'Activa', 'role' => 'Socio desde 2022', 'members' => 86, 'color' => '#b45309'],
            ['id' => 3, 'name' => 'Cowork Nube', 'admin' => 'Ana Beltrán', 'email' => 'hola@cowork-nube.mx', 'phone' => '55 3300 4455', 'created' => '21 feb 2026', 'status' => 'Suspendida', 'role' => 'Socio', 'members' => 41, 'color' => '#2563eb'],
            ['id' => 4, 'name' => 'Grupo Vértice', 'admin' => 'Hugo Salinas', 'email' => 'rh@vertice.mx', 'phone' => '55 7700 8899', 'created' => '09 mar 2026', 'status' => 'Activa', 'role' => 'Socio', 'members' => 203, 'color' => '#9333ea'],
            ['id' => 5, 'name' => 'Asociación Ceiba', 'admin' => 'Paola Núñez', 'email' => 'admin@ceiba.org', 'phone' => '55 2200 6677', 'created' => '30 mar 2026', 'status' => 'Activa', 'role' => 'Socio', 'members' => 57, 'color' => '#dc2626'],
        ];
    }

    public static function members(): array
    {
        $rows = [
            ['Marcela Ríos', 'Directora general', 'Dirección', 'Administrador', 'Activo', '10 ene 2024'],
            ['Luis Ferrer', 'Gerente comercial', 'Ventas', 'Usuario', 'Activo', '22 ene 2024'],
            ['Ana Beltrán', 'Diseñadora UX', 'Producto', 'Usuario', 'Activo', '14 mar 2024'],
            ['Hugo Salinas', 'Contador', 'Finanzas', 'Usuario', 'Invitado', '—'],
            ['Paola Núñez', 'Coordinadora de eventos', 'Comunidad', 'Administrador', 'Activo', '05 abr 2024'],
            ['Diego Cárdenas', 'Desarrollador', 'Tecnología', 'Usuario', 'Activo', '18 may 2024'],
            ['Sofía Montes', 'Analista de RH', 'Recursos Humanos', 'Usuario', 'Suspendido', '02 jun 2024'],
            ['Iván Olvera', 'Ejecutivo de cuentas', 'Ventas', 'Usuario', 'Activo', '30 jun 2024'],
            ['Valeria Pineda', 'Marketing', 'Comunidad', 'Usuario', 'Activo', '11 jul 2024'],
            ['Rodrigo Téllez', 'Soporte', 'Tecnología', 'Usuario', 'Invitado', '—'],
            ['Karla Mejía', 'Legal', 'Dirección', 'Usuario', 'Activo', '25 ago 2024'],
            ['Emilio Arce', 'Logística', 'Operaciones', 'Usuario', 'Activo', '03 sep 2024'],
        ];
        return array_map(fn ($r, $i) => [
            'id' => $i + 1, 'name' => $r[0], 'title' => $r[1], 'area' => $r[2], 'rol' => $r[3], 'status' => $r[4], 'since' => $r[5],
            'email' => strtolower(str_replace(' ', '.', iconv('UTF-8', 'ASCII//TRANSLIT', $r[0]))) . '@aurora.mx', 'phone' => '55 ' . rand(1000, 9999) . ' ' . rand(1000, 9999),
        ], $rows, array_keys($rows));
    }

    public static function posts(): array
    {
        return [
            ['id' => 1, 'author' => 'Marcela Ríos', 'title' => 'Directora general', 'time' => 'Hace 2 h', 'pinned' => true, 'official' => true, 'text' => '📣 Bienvenidos a la nueva comunidad digital del Club Aurora. Aquí compartiremos anuncios, eventos y todo lo que ocurre en nuestra red.', 'image' => null, 'likes' => 24, 'liked' => true,
                'comments' => [['Luis Ferrer', 'Excelente iniciativa, felicidades al equipo.'], ['Ana Beltrán', '¡Ya quiero ver los primeros eventos!']]],
            ['id' => 2, 'author' => 'Ana Beltrán', 'title' => 'Diseñadora UX', 'time' => 'Hace 5 h', 'pinned' => false, 'official' => false, 'text' => 'Compartimos las fotos del taller de la semana pasada. ¡Gracias a todos los que participaron!', 'image' => 'Taller de innovación', 'likes' => 11, 'liked' => false,
                'comments' => [['Paola Núñez', 'Quedaron hermosas, gracias por compartir.']]],
            ['id' => 3, 'author' => 'Diego Cárdenas', 'title' => 'Desarrollador', 'time' => 'Ayer', 'pinned' => false, 'official' => false, 'text' => '¿Alguien conoce un buen proveedor de coworking en la zona norte? Estamos evaluando opciones para el equipo.', 'image' => null, 'likes' => 3, 'liked' => false, 'comments' => []],
            ['id' => 4, 'author' => 'Paola Núñez', 'title' => 'Coordinadora de eventos', 'time' => 'Hace 2 días', 'pinned' => false, 'official' => true, 'text' => 'Recordatorio: el viernes cerramos inscripciones para la Convivencia de fin de año. Confirma tu asistencia en la sección de Eventos.', 'image' => null, 'likes' => 17, 'liked' => false, 'comments' => [['Hugo Salinas', 'Confirmado, ahí nos vemos.']]],
        ];
    }

    public static function events(): array
    {
        return [
            ['id' => 1, 'title' => 'Taller de liderazgo comunitario', 'day' => '05', 'month' => 'Nov', 'date' => 'Jueves 5 de noviembre de 2026', 'time' => '10:00 – 13:00', 'place' => 'Sala Polanco, CDMX', 'mode' => 'Presencial', 'organizer' => 'Paola Núñez', 'cap' => 40, 'going' => 28, 'status' => 'Programado', 'desc' => 'Un taller práctico para fortalecer habilidades de liderazgo dentro de la comunidad. Incluye dinámicas en grupo, casos reales y un espacio para networking.'],
            ['id' => 2, 'title' => 'Desayuno de networking', 'day' => '12', 'month' => 'Nov', 'date' => 'Jueves 12 de noviembre de 2026', 'time' => '08:30 – 10:00', 'place' => 'Terraza Aurora', 'mode' => 'Presencial', 'organizer' => 'Marcela Ríos', 'cap' => 60, 'going' => 41, 'status' => 'Programado', 'desc' => 'Un desayuno para conocer a nuevos miembros y compartir oportunidades.'],
            ['id' => 3, 'title' => 'Webinar: tendencias 2027', 'day' => '19', 'month' => 'Nov', 'date' => 'Jueves 19 de noviembre de 2026', 'time' => '17:00 – 18:00', 'place' => 'En línea (Zoom)', 'mode' => 'Virtual', 'organizer' => 'Ana Beltrán', 'cap' => 200, 'going' => 96, 'status' => 'Programado', 'desc' => 'Una conversación abierta sobre las tendencias que marcarán el próximo año.'],
            ['id' => 4, 'title' => 'Convivencia de fin de año', 'day' => '12', 'month' => 'Dic', 'date' => 'Sábado 12 de diciembre de 2026', 'time' => '19:00 – 23:00', 'place' => 'Hacienda Los Arcos', 'mode' => 'Presencial', 'organizer' => 'Paola Núñez', 'cap' => 150, 'going' => 72, 'status' => 'Programado', 'desc' => 'Cena y brindis para cerrar el año con toda la comunidad.'],
            ['id' => 5, 'title' => 'Junta de socios (cancelada)', 'day' => '27', 'month' => 'Oct', 'date' => 'Martes 27 de octubre de 2026', 'time' => '18:00 – 19:00', 'place' => 'Sala de juntas', 'mode' => 'Presencial', 'organizer' => 'Marcela Ríos', 'cap' => 30, 'going' => 0, 'status' => 'Cancelado', 'desc' => 'Evento cancelado por reprogramación.'],
        ];
    }

    public static function conversations(): array
    {
        return [
            ['id' => 1, 'name' => 'Ana Beltrán', 'last' => 'Perfecto, nos vemos en el taller 🙌', 'time' => '10:42', 'unread' => 2, 'type' => 'directo'],
            ['id' => 2, 'name' => 'Canal: Anuncios', 'last' => 'Marcela: Ya está abierto el registro.', 'time' => '09:15', 'unread' => 0, 'type' => 'canal'],
            ['id' => 3, 'name' => 'Luis Ferrer', 'last' => '¿Me pasas el contacto del proveedor?', 'time' => 'Ayer', 'unread' => 1, 'type' => 'directo'],
            ['id' => 4, 'name' => 'Canal: Tecnología', 'last' => 'Diego: Subí la guía de integración.', 'time' => 'Ayer', 'unread' => 0, 'type' => 'canal'],
            ['id' => 5, 'name' => 'Paola Núñez', 'last' => 'Gracias por confirmar.', 'time' => 'Lun', 'unread' => 0, 'type' => 'directo'],
        ];
    }

    public static function messages(): array
    {
        return [
            ['me' => false, 'text' => 'Hola Zamiel, ¿vas a asistir al taller del jueves?', 'time' => '10:30'],
            ['me' => true, 'text' => '¡Hola Ana! Sí, ya confirmé mi asistencia.', 'time' => '10:35'],
            ['me' => false, 'text' => 'Genial. Llevaré el material impreso para todos.', 'time' => '10:40'],
            ['me' => false, 'text' => 'Perfecto, nos vemos en el taller 🙌', 'time' => '10:42'],
        ];
    }

    public static function notifications(): array
    {
        return [
            ['icon' => 'calendar', 'text' => 'Nuevo evento: Taller de liderazgo comunitario', 'time' => 'Hace 1 h', 'unread' => true],
            ['icon' => 'bookmark', 'text' => 'Marcela Ríos fijó una publicación importante', 'time' => 'Hace 3 h', 'unread' => true],
            ['icon' => 'message', 'text' => 'Ana Beltrán comentó en tu publicación', 'time' => 'Ayer', 'unread' => false],
            ['icon' => 'clock', 'text' => 'Recordatorio: Desayuno de networking mañana a las 08:30', 'time' => 'Ayer', 'unread' => false],
            ['icon' => 'user', 'text' => 'Bienvenido a Club Aurora', 'time' => 'Hace 2 días', 'unread' => false],
        ];
    }

    public static function integrations(): array
    {
        return [
            ['name' => 'Google Workspace', 'abbr' => 'G', 'color' => '#2563eb', 'desc' => 'Sincroniza calendarios y contactos con la cuenta de Google de la empresa.', 'connected' => true],
            ['name' => 'HubSpot', 'abbr' => 'H', 'color' => '#ea580c', 'desc' => 'Envía los contactos nuevos de la comunidad a tu CRM automáticamente.', 'connected' => true],
            ['name' => 'WhatsApp', 'abbr' => 'W', 'color' => '#16a34a', 'desc' => 'Notifica eventos y anuncios por WhatsApp mediante flujos de n8n.', 'connected' => false],
            ['name' => 'Correo electrónico', 'abbr' => '@', 'color' => '#6b7280', 'desc' => 'Invitaciones, recordatorios y avisos por correo desde n8n.', 'connected' => true],
        ];
    }
}
